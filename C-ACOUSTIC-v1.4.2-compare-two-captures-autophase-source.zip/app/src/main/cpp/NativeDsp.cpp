#include <jni.h>
#include <algorithm>
#include <cmath>
#include <complex>
#include <cstdint>
#include <string>
#include <vector>

static float rms(const jfloat* x, jsize n) {
    if (n <= 0) return 0.0f;
    double sum = 0.0;
    for (jsize i = 0; i < n; ++i) sum += static_cast<double>(x[i]) * x[i];
    return static_cast<float>(std::sqrt(sum / n));
}

static int estimateLag(const jfloat* ref, const jfloat* measured, jsize n, int maxLag) {
    if (n <= 0) return 0;
    maxLag = std::max(0, std::min<int>(maxLag, static_cast<int>(n) - 1));
    double best = -1.0;
    int bestLag = 0;
    for (int lag = -maxLag; lag <= maxLag; ++lag) {
        double corr = 0.0;
        for (int i = 0; i < n; ++i) {
            const int j = i + lag;
            if (j >= 0 && j < n) corr += static_cast<double>(ref[i]) * measured[j];
        }
        const double score = std::abs(corr);
        if (score > best) { best = score; bestLag = lag; }
    }
    return bestLag;
}

static std::vector<float> fftMagnitude(const jfloat* input, jsize n) {
    if (n <= 0 || (n & (n - 1)) != 0) return {};
    std::vector<std::complex<double>> a(static_cast<size_t>(n));
    for (jsize i = 0; i < n; ++i) {
        const double w = n == 1 ? 1.0 : 0.5 * (1.0 - std::cos(2.0 * M_PI * i / (n - 1)));
        a[static_cast<size_t>(i)] = std::complex<double>(input[i] * w, 0.0);
    }
    for (size_t i = 1, j = 0; i < static_cast<size_t>(n); ++i) {
        size_t bit = static_cast<size_t>(n) >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (size_t len = 2; len <= static_cast<size_t>(n); len <<= 1) {
        const double angle = -2.0 * M_PI / static_cast<double>(len);
        const std::complex<double> wlen(std::cos(angle), std::sin(angle));
        for (size_t i = 0; i < static_cast<size_t>(n); i += len) {
            std::complex<double> w(1.0, 0.0);
            for (size_t j = 0; j < len / 2; ++j) {
                const auto u = a[i + j];
                const auto v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wlen;
            }
        }
    }
    std::vector<float> out(static_cast<size_t>(n) / 2 + 1);
    for (size_t i = 0; i < out.size(); ++i) out[i] = static_cast<float>(std::abs(a[i]));
    return out;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_candstech_cacoustic_MainActivity_nativeDspStatus(JNIEnv* env, jobject) {
    return env->NewStringUTF("JNI loaded · FFT/RMS/correlation primitives");
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_candstech_cacoustic_MainActivity_nativeRms(JNIEnv* env, jobject, jfloatArray samples) {
    if (!samples) return 0.0f;
    const jsize n = env->GetArrayLength(samples);
    jfloat* data = env->GetFloatArrayElements(samples, nullptr);
    const float result = rms(data, n);
    env->ReleaseFloatArrayElements(samples, data, JNI_ABORT);
    return result;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_candstech_cacoustic_MainActivity_nativeEstimateLag(JNIEnv* env, jobject, jfloatArray reference, jfloatArray measured, jint maxLag) {
    if (!reference || !measured) return 0;
    const jsize n = std::min(env->GetArrayLength(reference), env->GetArrayLength(measured));
    jfloat* a = env->GetFloatArrayElements(reference, nullptr);
    jfloat* b = env->GetFloatArrayElements(measured, nullptr);
    const int lag = estimateLag(a, b, n, maxLag);
    env->ReleaseFloatArrayElements(reference, a, JNI_ABORT);
    env->ReleaseFloatArrayElements(measured, b, JNI_ABORT);
    return lag;
}

// Normalized, mean-removed cross-correlation. Searches non-negative delay
// (measured follows reference), coarse-to-fine to keep a 300 ms window practical.
extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_candstech_cacoustic_MainActivity_nativeEstimateLagNormalized(JNIEnv* env, jobject, jfloatArray reference, jfloatArray measured, jint maxLag) {
    jfloatArray out = env->NewFloatArray(2);
    if (!reference || !measured) return out;
    const jsize n = std::min(env->GetArrayLength(reference), env->GetArrayLength(measured));
    if (n < 64) return out;
    jfloat* a = env->GetFloatArrayElements(reference, nullptr);
    jfloat* b = env->GetFloatArrayElements(measured, nullptr);
    maxLag = std::max(0, std::min<int>(maxLag, n / 2));
    double ma=0, mb=0;
    for (jsize i=0;i<n;++i) { ma += a[i]; mb += b[i]; }
    ma/=n; mb/=n;
    const int stride = std::max(1, maxLag / 512);
    int bestLag=0; double best=-1.0;
    auto scoreAt = [&](int lag, int sampleStride) {
        const int count = n-lag;
        if (count < 32) return -1.0;
        // Recompute means on the actual overlapping segments. Using whole-buffer
        // means biases the normalized score when lag is large.
        double sx=0, sy=0; int samples=0;
        for(int i=0;i<count;i+=sampleStride) { sx+=a[i]; sy+=b[i+lag]; ++samples; }
        if(samples < 16) return -1.0;
        const double mx=sx/samples, my=sy/samples;
        double xy=0, xx=0, yy=0;
        for(int i=0;i<count;i+=sampleStride) {
            double x=a[i]-mx, y=b[i+lag]-my;
            xy+=x*y; xx+=x*x; yy+=y*y;
        }
        return (xx>1e-20 && yy>1e-20) ? std::abs(xy)/std::sqrt(xx*yy) : 0.0;
    };
    for(int lag=0;lag<=maxLag;lag+=stride) { double sc=scoreAt(lag,stride); if(sc>best){best=sc;bestLag=lag;} }
    const int lo=std::max(0,bestLag-stride), hi=std::min<int>(maxLag,bestLag+stride);
    // Critical accuracy fix: refine every sample, not every coarse stride.
    best=-1.0;
    for(int lag=lo;lag<=hi;++lag) { double sc=scoreAt(lag,1); if(sc>best){best=sc;bestLag=lag;} }
    jfloat vals[2] = {static_cast<float>(bestLag), static_cast<float>(std::max(0.0,best))};
    env->SetFloatArrayRegion(out,0,2,vals);
    env->ReleaseFloatArrayElements(reference,a,JNI_ABORT); env->ReleaseFloatArrayElements(measured,b,JNI_ABORT);
    return out;
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_candstech_cacoustic_MainActivity_nativeFftMagnitude(JNIEnv* env, jobject, jfloatArray samples) {
    if (!samples) return env->NewFloatArray(0);
    const jsize n = env->GetArrayLength(samples);
    jfloat* data = env->GetFloatArrayElements(samples, nullptr);
    auto mags = fftMagnitude(data, n);
    env->ReleaseFloatArrayElements(samples, data, JNI_ABORT);
    jfloatArray out = env->NewFloatArray(static_cast<jsize>(mags.size()));
    if (!mags.empty()) env->SetFloatArrayRegion(out, 0, static_cast<jsize>(mags.size()), mags.data());
    return out;
}

static std::vector<std::complex<double>> fftComplex(const jfloat* input, jsize n, int windowType) {
    if (n <= 0 || (n & (n - 1)) != 0) return {};
    std::vector<std::complex<double>> a(static_cast<size_t>(n));
    for (jsize i=0;i<n;++i) {
        double w = 1.0;
        if (windowType == 0) w = 0.5 * (1.0 - std::cos(2.0*M_PI*i/(n-1)));
        else if (windowType == 1) w = 0.54 - 0.46 * std::cos(2.0*M_PI*i/(n-1));
        a[static_cast<size_t>(i)] = {input[i]*w,0.0};
    }
    for(size_t i=1,j=0;i<static_cast<size_t>(n);++i){size_t bit=static_cast<size_t>(n)>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;if(i<j)std::swap(a[i],a[j]);}
    for(size_t len=2;len<=static_cast<size_t>(n);len<<=1){double angle=-2.0*M_PI/len;std::complex<double> wl(std::cos(angle),std::sin(angle));for(size_t i=0;i<static_cast<size_t>(n);i+=len){std::complex<double>w(1,0);for(size_t j=0;j<len/2;++j){auto u=a[i+j],v=a[i+j+len/2]*w;a[i+j]=u+v;a[i+j+len/2]=u-v;w*=wl;}}}
    return a;
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_candstech_cacoustic_MainActivity_nativeTransferFrame(JNIEnv* env, jobject, jfloatArray reference, jfloatArray measured, jint windowType) {
    if(!reference || !measured) return env->NewFloatArray(0);
    jsize n=std::min(env->GetArrayLength(reference),env->GetArrayLength(measured));
    jfloat* r=env->GetFloatArrayElements(reference,nullptr); jfloat* m=env->GetFloatArrayElements(measured,nullptr);
    auto R=fftComplex(r,n,windowType); auto M=fftComplex(m,n,windowType);
    env->ReleaseFloatArrayElements(reference,r,JNI_ABORT); env->ReleaseFloatArrayElements(measured,m,JNI_ABORT);
    size_t bins=static_cast<size_t>(n)/2+1; std::vector<float> out(bins*4);
    for(size_t k=0;k<bins;++k){ auto cross=M[k]*std::conj(R[k]); out[k*4]=static_cast<float>(std::norm(R[k])); out[k*4+1]=static_cast<float>(std::norm(M[k])); out[k*4+2]=static_cast<float>(cross.real()); out[k*4+3]=static_cast<float>(cross.imag()); }
    jfloatArray result=env->NewFloatArray(static_cast<jsize>(out.size())); if(!out.empty()) env->SetFloatArrayRegion(result,0,static_cast<jsize>(out.size()),out.data()); return result;
}
