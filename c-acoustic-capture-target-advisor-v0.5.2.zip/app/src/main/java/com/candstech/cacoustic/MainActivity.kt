package com.candstech.cacoustic

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.media.AudioFormat
import android.os.Build
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.provider.Settings
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private external fun nativeDspStatus(): String
    private external fun nativeRms(samples: FloatArray): Float
    private external fun nativeEstimateLag(reference: FloatArray, measured: FloatArray, maxLag: Int): Int
    private external fun nativeFftMagnitude(samples: FloatArray): FloatArray
    private external fun nativeTransferFrame(reference: FloatArray, measured: FloatArray): FloatArray
    companion object { private const val MIC_REQUEST = 41; init { System.loadLibrary("cacoustic_dsp") } }

    private val bg = Color.rgb(5, 14, 25); private val panel = Color.rgb(12, 27, 42)
    private val cyan = Color.rgb(53, 215, 239); private val muted = Color.rgb(151, 177, 196)
    private var selected = "RTA"; private lateinit var content: LinearLayout
    private var splOffsetDb = 120f
    @Volatile private var recording = false
    private var audioRecord: AudioRecord? = null
    private var audioThread: Thread? = null
    private var spectrumView: SpectrumView? = null
    private var statusText: TextView? = null
    private var levelText: TextView? = null
    private var transferView: TransferView? = null
    private var transferStatus: TextView? = null
    @Volatile private var signalRunning = false
    private var signalMode = "Pink Noise"
    private var signalTrack: AudioTrack? = null
    private var signalThread: Thread? = null
    @Volatile private var tfMagnitude = FloatArray(2049)
    @Volatile private var tfPhase = FloatArray(2049)
    @Volatile private var tfCoherence = FloatArray(2049)
    private var tfDisplayMode = "Magnitude"
    @Volatile private var latestSpectrum = FloatArray(2049)
    @Volatile private var latestRms = 0f
    @Volatile private var latestPeak = 0f

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); splOffsetDb = getPreferences(Context.MODE_PRIVATE).getFloat("spl_offset_db", 120f); window.statusBarColor=bg; window.navigationBarColor=bg; buildShell(); renderPage() }
    override fun onDestroy() { stopCapture(); stopSignal(); super.onDestroy() }
    override fun onPause() { super.onPause(); stopCapture(); stopSignal() }

    private fun buildShell() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(12,10,12,8) }
        root.addView(TextView(this).apply { text="C ACOUSTIC"; textSize=27f; typeface=android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD); setTextColor(cyan) })
        root.addView(TextView(this).apply { text="CANDSTECH  •  AUDIO ANALYSIS & SYSTEM TUNING"; textSize=10f; setTextColor(muted); setPadding(0,2,0,12) })
        val hs=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false }; val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("RTA","Transfer","Impulse","SPL","Signal","Capture","Audio I/O","Auto Phase").forEach { tab ->
            tabs.addView(Button(this).apply { text=tab; textSize=10f; isAllCaps=false; setTextColor(if(tab==selected) cyan else Color.WHITE); setBackgroundColor(if(tab==selected) Color.rgb(20,55,69) else panel); setOnClickListener { stopCapture(); stopSignal(); selected=tab; buildShell(); renderPage() } },LinearLayout.LayoutParams(-2,-2).apply { rightMargin=5 })
        }
        hs.addView(tabs); root.addView(hs)
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,14,0,0) }
        root.addView(ScrollView(this).apply { addView(content) },LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun renderPage() {
        content.removeAllViews(); spectrumView=null; statusText=null; levelText=null; transferView=null; transferStatus=null
        when(selected) {
            "RTA" -> {
                heading("REAL-TIME ANALYZER","Live microphone FFT • 48 kHz preferred")
                metric("FFT SIZE","4096","Frequency resolution depends on sample rate")
                graphBox("RTA SPECTRUM")
                levelText=TextView(this).apply { text="Level: —"; textSize=14f; setTextColor(cyan); setPadding(4,8,4,8) }; content.addView(levelText)
                statusText=TextView(this).apply { text="Mikrofon belum aktif"; textSize=11f; setTextColor(muted); setPadding(4,4,4,8) }; content.addView(statusText)
                action("Start live RTA") { requestMicAndStart() }; action("Stop capture") { stopCapture(); statusText?.text="Capture dihentikan" }
            }
            "Transfer" -> {
                heading("TRANSFER FUNCTION", "Dual-channel • H1 estimate • magnitude / phase / coherence")
                metric("INPUT ROUTING", "Stereo input required", "Channel 1 = reference, channel 2 = measurement. Use a 2-in USB interface with shared clock for meaningful results.")
                val v=TransferView(this); transferView=v
                val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(10,10,10,10) }
                box.addView(TextView(this).apply { text="TRANSFER MAGNITUDE (dB)"; setTextColor(Color.WHITE); textSize=12f })
                box.addView(v,LinearLayout.LayoutParams(-1,230).apply { topMargin=8 })
                content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 })
                val modes=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
                listOf("Magnitude","Phase","Coherence").forEach { mode -> modes.addView(Button(this).apply { text=mode; isAllCaps=false; setTextColor(cyan); setOnClickListener { tfDisplayMode=mode; transferView?.invalidate() } },LinearLayout.LayoutParams(0,-2,1f)) }
                content.addView(modes)
                transferStatus=TextView(this).apply { text="Belum ada capture dua kanal"; textSize=12f; setTextColor(cyan); setPadding(4,6,4,10) }; content.addView(transferStatus)
                action("Start 2-channel Transfer") { requestMicAndStartTransfer() }
                action("Stop capture") { stopCapture(); transferStatus?.text="Capture dihentikan" }
                info("Transfer Function memakai estimasi cross-spectrum H1 dan coherence berbasis averaging. Jika Android hanya menyediakan satu kanal atau menggandakan mono ke stereo, hasil tidak valid. Gunakan input reference dan measurement dari interface dua kanal yang sama; ukur dengan loopback/reference elektrik dan mikrofon ukur. Belum divalidasi untuk akurasi profesional.")
            }
            "Impulse" -> { heading("IMPULSE RESPONSE","Arrival time & delay analysis"); graphBox("IMPULSE RESPONSE"); info("Live capture satu kanal tersedia melalui RTA. IR windowing, timing reference, dan peak detection masih perlu validasi sebelum digunakan untuk pengukuran profesional.") }
            "SPL" -> {
                heading("SPL METER", "Relative level • manual reference calibration")
                metric("CALIBRATION OFFSET", String.format(java.util.Locale.US, "%.1f dB", splOffsetDb), "Offset awal hanya perkiraan; kalibrasikan dengan sound level calibrator atau meter referensi.")
                val input = EditText(this).apply {
                    setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                    hint = "Offset dB (mis. 120.0)"; setText(String.format(java.util.Locale.US, "%.1f", splOffsetDb)); setTextColor(Color.WHITE); setHintTextColor(muted); setBackgroundColor(panel)
                }
                content.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
                action("Save calibration offset") {
                    val value = input.text.toString().toFloatOrNull()
                    if (value == null || value !in 0f..200f) Toast.makeText(this, "Masukkan offset 0–200 dB", Toast.LENGTH_LONG).show()
                    else { splOffsetDb = value; getPreferences(Context.MODE_PRIVATE).edit().putFloat("spl_offset_db", value).apply(); Toast.makeText(this, "Offset tersimpan. Verifikasi dengan meter referensi.", Toast.LENGTH_LONG).show(); renderPage() }
                }
                levelText = TextView(this).apply { text = "SPL: menunggu capture"; textSize = 20f; setTextColor(cyan); setPadding(4, 12, 4, 8) }; content.addView(levelText)
                statusText = TextView(this).apply { text = "Belum ada capture"; textSize = 11f; setTextColor(muted); setPadding(4, 4, 4, 8) }; content.addView(statusText)
                action("Start SPL capture") { requestMicAndStart() }
                action("Stop capture") { stopCapture(); statusText?.text = "Capture dihentikan" }
                info("SPL dihitung sebagai dBFS + offset manual. Ini belum menerapkan weighting A/C, response time, sensitivitas mikrofon, atau sertifikasi akurasi. Jangan anggap sebagai SPL terkalibrasi tanpa pembandingan alat referensi.")
            }
            "Signal" -> {
                heading("SIGNAL GENERATOR", "Pilih jenis sinyal, lalu ON/OFF")
                metric("AUDIO OUTPUT", "Pink Noise • Pink Sweep", "Sinyal dikirim ke output audio Android yang aktif, termasuk USB DAC jika didukung.")
                content.addView(TextView(this).apply {
                    text = "SIGNAL TYPE"
                    textSize = 11f
                    setTextColor(muted)
                    setPadding(4, 8, 4, 4)
                })
                val choices = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                choices.addView(Button(this).apply {
                    text = "Pink Noise"
                    isAllCaps = false
                    setTextColor(if (signalMode == "Pink Noise") cyan else Color.WHITE)
                    setBackgroundColor(if (signalMode == "Pink Noise") Color.rgb(20,55,69) else panel)
                    setOnClickListener {
                        if (signalRunning) stopSignal()
                        signalMode = "Pink Noise"
                        renderPage()
                    }
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 6 })
                choices.addView(Button(this).apply {
                    text = "Pink Sweep"
                    isAllCaps = false
                    setTextColor(if (signalMode == "Pink Sweep") cyan else Color.WHITE)
                    setBackgroundColor(if (signalMode == "Pink Sweep") Color.rgb(20,55,69) else panel)
                    setOnClickListener {
                        if (signalRunning) stopSignal()
                        signalMode = "Pink Sweep"
                        renderPage()
                    }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                content.addView(choices)
                statusText=TextView(this).apply {
                    text = if (signalRunning) "$signalMode aktif" else "$signalMode siap • Generator OFF"
                    textSize = 14f
                    setTextColor(cyan)
                    setPadding(4, 12, 4, 10)
                }
                content.addView(statusText)
                action(if (signalRunning) "OFF • Stop Generator" else "ON • Start Generator") {
                    if (signalRunning) {
                        stopSignal()
                        statusText?.text = "$signalMode • Generator OFF"
                    } else {
                        startSignal(signalMode == "Pink Sweep")
                    }
                }
                info("Pilih Pink Noise atau Pink Sweep, lalu tekan ON. Tekan OFF untuk menghentikan output. Pink Sweep berjalan logaritmik 20 Hz–20 kHz dan berulang sekitar 10 detik. Mulai dengan volume rendah; output level belum dikalibrasi.")
            }
            "Capture" -> {
                heading("CAPTURE MANAGER", "Pilih hasil ukur • lihat respons • analisis fase dan gain")
                metric("CAPTURE LIBRARY", "Belum ada capture tersimpan", "Penyimpanan hasil ukur dan pemuatan ulang data harus diaktifkan sebelum analisis bisa memakai hasil nyata.")
                info("Alur yang direncanakan: simpan capture dengan nama, waktu, sample rate, referensi kanal, magnitude/fase atau impulse response, lalu pilih satu atau beberapa hasil untuk dibandingkan.")
                heading("TARGET CURVE & GAIN ADVISOR", "Equal-loudness 80 phon • rentang target 20 Hz–20 kHz")
                metric("TARGET", "ISO 226 • 80 phon", "Gunakan tabel standar untuk frekuensi yang tersedia. Jangan mengarang nilai di atas rentang standar; wilayah 12,5–20 kHz perlu ditandai sebagai target yang belum ditentukan atau memakai target pilihan pengguna.")
                val targetOptions=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
                listOf("Equal-loudness • 80 phon","House Curve","Flat Response").forEach { label ->
                    targetOptions.addView(Button(this).apply { text=label; isAllCaps=false; setTextColor(if(label.startsWith("Equal-loudness")) cyan else Color.WHITE); setBackgroundColor(panel); setOnClickListener { Toast.makeText(this@MainActivity,"Target dipilih: $label. Perhitungan memerlukan data capture dan tabel target yang tervalidasi.",Toast.LENGTH_LONG).show() } },LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=5 })
                }
                content.addView(targetOptions)
                graphBox("MEASURED / TARGET / PREDICTED")
                info("Perhitungan yang akan digunakan: error(f) = target(f) − measured(f); kandidat filter EQ dioptimalkan dengan batas boost/cut dan headroom; prediksi = respons terukur + respons filter dalam dB. Ini belum menampilkan hasil nyata sampai capture tersimpan dan tabel target ISO tervalidasi diintegrasikan.")
                action("Capture Manager: simpan hasil ukur") { Toast.makeText(this,"Penyimpanan capture belum terimplementasi pada build ini.",Toast.LENGTH_LONG).show() }
                action("Buka Auto Phase") { selected="Auto Phase"; buildShell(); renderPage() }
            }
            "Audio I/O" -> { heading("AUDIO DEVICE & ROUTING","Android input devices • USB/OTG where supported"); action("Refresh audio devices") { listAudioDevices() }; action("Open Android sound settings") { startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }; info(nativeDspStatus()); listAudioDevices() }
            else -> { heading("AUTO PHASE","Main + sub alignment assistant"); metric("MODE","Analysis pending","Dual-channel capture needed for reliable alignment"); graphBox("MAIN + SUB ALIGNMENT"); info("Auto Phase belum memberi rekomendasi delay/polarity tanpa capture reference dan sub yang sinkron. Jangan gunakan estimasi sintetis untuk tuning sistem live."); action("Open Capture Manager") { selected="Capture"; buildShell(); renderPage() } }
        }
        content.addView(TextView(this).apply { text="C ACOUSTIC • LIVE RTA PROTOTYPE • DSP VALIDATION REQUIRED"; textSize=9f; setTextColor(muted); setPadding(0,18,0,8) })
    }
    private fun startSignal(sweep: Boolean) {
        stopSignal()
        stopCapture()
        val sr = 48000
        val minBytes = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBytes <= 0) { Toast.makeText(this, "Output audio tidak didukung", Toast.LENGTH_LONG).show(); return }
        try {
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(minBytes, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            if (track.state != AudioTrack.STATE_INITIALIZED) { track.release(); Toast.makeText(this, "AudioTrack gagal diinisialisasi", Toast.LENGTH_LONG).show(); return }
            signalTrack = track; signalRunning = true; track.play()
            statusText?.text = if (sweep) "Pink sweep aktif • 20 Hz–20 kHz • 10 s/putaran" else "Pink noise aktif"
            signalThread = thread(name="CAcousticSignal", isDaemon=true) {
                val block = ShortArray(2048)
                val rng = java.util.Random()
                var phase = 0.0
                var index = 0L
                var b0=0.0; var b1=0.0; var b2=0.0; var b3=0.0; var b4=0.0; var b5=0.0; var b6=0.0
                while (signalRunning) {
                    for (i in block.indices) {
                        val sample: Double
                        if (sweep) {
                            val t = (index % (sr * 10L)).toDouble() / sr
                            val duration = 10.0
                            val f0 = 20.0; val f1 = 20000.0
                            val k = duration / kotlin.math.ln(f1 / f0)
                            phase = 2.0 * Math.PI * f0 * k * (kotlin.math.exp(t / k) - 1.0)
                            sample = kotlin.math.sin(phase) * 0.18
                        } else {
                            val white = rng.nextDouble() * 2.0 - 1.0
                            b0 = 0.99886*b0 + white*0.0555179
                            b1 = 0.99332*b1 + white*0.0750759
                            b2 = 0.96900*b2 + white*0.1538520
                            b3 = 0.86650*b3 + white*0.3104856
                            b4 = 0.55000*b4 + white*0.5329522
                            b5 = -0.7616*b5 - white*0.0168980
                            val pink = b0+b1+b2+b3+b4+b5+b6+white*0.5362
                            b6 = white*0.115926
                            sample = (pink * 0.035).coerceIn(-0.25, 0.25)
                        }
                        block[i] = (sample.coerceIn(-0.25, 0.25) * 32767.0).toInt().toShort()
                        index++
                    }
                    var off = 0
                    while (off < block.size && signalRunning) {
                        val wrote = track.write(block, off, block.size-off, AudioTrack.WRITE_BLOCKING)
                        if (wrote <= 0) break else off += wrote
                    }
                }
            }
        } catch (e: Exception) {
            stopSignal()
            Toast.makeText(this, "Gagal memulai generator: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopSignal() {
        signalRunning = false
        try { signalTrack?.pause() } catch (_: Exception) {}
        try { signalTrack?.flush() } catch (_: Exception) {}
        try { signalTrack?.stop() } catch (_: Exception) {}
        try { signalTrack?.release() } catch (_: Exception) {}
        signalTrack = null
        signalThread = null
    }

    private fun requestMicAndStart() { if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),MIC_REQUEST); return }; startCapture() }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) { super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==MIC_REQUEST && grantResults.isNotEmpty() && grantResults[0]==PackageManager.PERMISSION_GRANTED) { if(selected=="Transfer") startTransferCapture() else startCapture() } else Toast.makeText(this,"Izin mikrofon diperlukan untuk RTA live",Toast.LENGTH_LONG).show() }

    private fun startCapture() {
        if(recording) return
        val sampleRate=48000; val minBytes=AudioRecord.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        if(minBytes<=0) { Toast.makeText(this,"Format audio 48 kHz tidak didukung; coba perangkat lain",Toast.LENGTH_LONG).show(); return }
        val bufferBytes=max(minBytes,4096*2*2)
        try {
            val rec=AudioRecord(MediaRecorder.AudioSource.UNPROCESSED,sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,bufferBytes).let { if(it.state!=AudioRecord.STATE_INITIALIZED) { it.release(); AudioRecord(MediaRecorder.AudioSource.MIC,sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,bufferBytes) } else it }
            if(rec.state!=AudioRecord.STATE_INITIALIZED) { rec.release(); Toast.makeText(this,"AudioRecord gagal diinisialisasi",Toast.LENGTH_LONG).show(); return }
            audioRecord=rec; recording=true; rec.startRecording(); statusText?.text="Capture aktif • 48 kHz • mikrofon Android"; Toast.makeText(this,"RTA live aktif",Toast.LENGTH_SHORT).show()
            audioThread=thread(name="CAcousticAudio", isDaemon=true) {
                val n=4096; val shorts=ShortArray(n); val floats=FloatArray(n)
                while(recording) {
                    var offset=0
                    while(offset<n && recording) { val got=rec.read(shorts,offset,n-offset,AudioRecord.READ_BLOCKING); if(got>0) offset+=got else break }
                    if(!recording || offset<n) continue
                    var peak=0f
                    for(i in 0 until n) { floats[i]=shorts[i]/32768f; peak=max(peak,kotlin.math.abs(floats[i])) }
                    latestRms=nativeRms(floats); latestPeak=peak
                    val mags=nativeFftMagnitude(floats); if(mags.isNotEmpty()) latestSpectrum=mags
                    runOnUiThread {
                        spectrumView?.invalidate()
                        if (selected == "SPL") levelText?.text = "Level estimasi ${formatDb(latestRms)} dBFS\nSPL relatif ${String.format(java.util.Locale.US, "%.1f", 20.0 * log10(max(1e-9f, latestRms).toDouble()) + splOffsetDb)} dB SPL"
                        else levelText?.text = "RMS ${formatDb(latestRms)} dBFS   •   Peak ${formatDb(latestPeak)} dBFS"
                        statusText?.text = "Capture aktif • ${sampleRate} Hz • input Android"
                    }
                }
            }
        } catch(e:Exception) { recording=false; Toast.makeText(this,"Gagal memulai audio: ${e.message}",Toast.LENGTH_LONG).show() }
    }
    private fun requestMicAndStartTransfer() {
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),MIC_REQUEST); return }
        startTransferCapture()
    }
    private fun startTransferCapture() {
        if(recording) return
        val sr=48000; val mask=AudioFormat.CHANNEL_IN_STEREO
        val minBytes=AudioRecord.getMinBufferSize(sr,mask,AudioFormat.ENCODING_PCM_16BIT)
        if(minBytes<=0) { transferStatus?.text="Stereo 48 kHz tidak didukung input ini. Coba interface USB 2-in."; return }
        val bytes=max(minBytes,4096*2*2)
        try {
            val rec=AudioRecord(MediaRecorder.AudioSource.UNPROCESSED,sr,mask,AudioFormat.ENCODING_PCM_16BIT,bytes)
            if(rec.state!=AudioRecord.STATE_INITIALIZED) { rec.release(); transferStatus?.text="AudioRecord stereo gagal. Perangkat mungkin hanya menyediakan input mono."; return }
            audioRecord=rec; recording=true; rec.startRecording(); transferStatus?.text="Capture stereo aktif • Ch1 reference / Ch2 measurement"
            audioThread=thread(name="CAcousticTransfer",isDaemon=true) {
                val n=4096; val interleaved=ShortArray(n*2); val r=FloatArray(n); val m=FloatArray(n)
                val avgR=FloatArray(n/2+1); val avgM=FloatArray(n/2+1); val avgCr=FloatArray(n/2+1); val avgCi=FloatArray(n/2+1); var frames=0
                while(recording) {
                    var off=0; while(off<interleaved.size && recording) { val got=rec.read(interleaved,off,interleaved.size-off,AudioRecord.READ_BLOCKING); if(got>0) off+=got else break }
                    if(!recording || off<interleaved.size) continue
                    for(i in 0 until n){r[i]=interleaved[i*2]/32768f;m[i]=interleaved[i*2+1]/32768f}
                    val raw=nativeTransferFrame(r,m); if(raw.size<(n/2+1)*4) continue
                    frames++
                    for(k in avgR.indices){ val j=k*4; avgR[k]=avgR[k]*0.85f+raw[j]*0.15f; avgM[k]=avgM[k]*0.85f+raw[j+1]*0.15f; avgCr[k]=avgCr[k]*0.85f+raw[j+2]*0.15f; avgCi[k]=avgCi[k]*0.85f+raw[j+3]*0.15f }
                    for(k in avgR.indices){ tfMagnitude[k]=(10.0*log10(max(1e-12f,avgM[k])/max(1e-12f,avgR[k]))).toFloat(); tfPhase[k]=Math.toDegrees(kotlin.math.atan2(avgCi[k].toDouble(),avgCr[k].toDouble())).toFloat(); tfCoherence[k]=((avgCr[k]*avgCr[k]+avgCi[k]*avgCi[k])/max(1e-20f,avgR[k]*avgM[k])).coerceIn(0f,1f) }
                    runOnUiThread { transferView?.invalidate(); transferStatus?.text="TF live • 48 kHz • avg frames $frames • coherence = estimate" }
                }
            }
        } catch(e:Exception) { recording=false; transferStatus?.text="Gagal memulai stereo capture: ${e.message}" }
    }

    private fun stopCapture() { recording=false; try { audioRecord?.stop() } catch(_:Exception){}; try { audioRecord?.release() } catch(_:Exception){}; audioRecord=null; audioThread=null }
    private fun formatDb(v:Float):String = if(v<=0f) "−∞" else String.format(java.util.Locale.US,"%.1f",20.0*log10(v.toDouble()))

    private fun heading(t:String,d:String) { content.addView(TextView(this).apply { text=t; textSize=17f; setTextColor(Color.WHITE); typeface=android.graphics.Typeface.DEFAULT_BOLD }); content.addView(TextView(this).apply { text=d; textSize=11f; setTextColor(muted); setPadding(0,3,0,12) }) }
    private fun metric(l:String,v:String,d:String) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(12,12,12,12) }; box.addView(TextView(this).apply { text=l; textSize=10f; setTextColor(muted) }); box.addView(TextView(this).apply { text=v; textSize=20f; setTextColor(cyan); typeface=android.graphics.Typeface.DEFAULT_BOLD; setPadding(0,4,0,2) }); box.addView(TextView(this).apply { text=d; textSize=11f; setTextColor(Color.WHITE) }); content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 }) }
    private fun graphBox(title:String) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(10,10,10,12) }; box.addView(TextView(this).apply { text=title; textSize=12f; setTextColor(Color.WHITE); typeface=android.graphics.Typeface.DEFAULT_BOLD }); val graph=SpectrumView(this); spectrumView=graph; box.addView(graph,LinearLayout.LayoutParams(-1,220).apply { topMargin=8 }); content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 }) }
    private fun info(s:String) { content.addView(TextView(this).apply { text=s; textSize=12f; setTextColor(muted); setPadding(6,8,6,12) }) }
    private fun action(label:String,fn:()->Unit) { content.addView(Button(this).apply { text=label; isAllCaps=false; setTextColor(cyan); setOnClickListener { fn() } },LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 }) }
    private fun listAudioDevices() { val am=getSystemService(Context.AUDIO_SERVICE) as AudioManager; val devices=if(Build.VERSION.SDK_INT>=23) am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList() else emptyList(); val lines=devices.map { d -> "${d.productName} • ${typeName(d.type)} • ${d.channelCounts.joinToString()} ch" }; info(if(lines.isEmpty()) "Tidak ada input device eksternal yang terdeteksi. Mikrofon bawaan mungkin tetap tersedia melalui AudioRecord." else "Input terdeteksi:\n"+lines.joinToString("\n")) }
    private fun typeName(t:Int)=when(t){AudioDeviceInfo.TYPE_BUILTIN_MIC->"Built-in mic";AudioDeviceInfo.TYPE_USB_DEVICE->"USB device";AudioDeviceInfo.TYPE_USB_HEADSET->"USB headset";AudioDeviceInfo.TYPE_WIRED_HEADSET->"Wired headset";AudioDeviceInfo.TYPE_BLUETOOTH_SCO->"Bluetooth SCO";else->"Audio type $t"}

    private inner class TransferView(ctx:Context):View(ctx) {
        private val grid=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(35,57,73); strokeWidth=1f }
        private val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cyan; strokeWidth=2.5f; style=Paint.Style.STROKE }
        private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=muted; textSize=10f }
        override fun onDraw(c:Canvas) { super.onDraw(c); c.drawColor(Color.rgb(7,19,31)); val l=36f; val r=width-8f; val t=12f; val b=height-20f
            val minY=when(tfDisplayMode){"Phase"->-180f;"Coherence"->0f;else->-18f}; val maxY=when(tfDisplayMode){"Phase"->180f;"Coherence"->1f;else->18f}
            for(i in 0..6){val v=maxY-(maxY-minY)*i/6f;val y=t+(b-t)*i/6f;c.drawLine(l,y,r,y,grid);c.drawText(String.format(java.util.Locale.US,"%.0f",v),2f,y-2,text)}
            for(i in 0..4){val x=l+(r-l)*i/4f;c.drawLine(x,t,x,b,grid);c.drawText(listOf("20","100","1k","10k","20k")[i],x-8,b+14,text)}
            val a=when(tfDisplayMode){"Phase"->tfPhase;"Coherence"->tfCoherence;else->tfMagnitude}; if(a.size<4)return; val path=Path(); val count=min(500,a.size-1)
            for(i in 1..count){val v=a[i].coerceIn(minY,maxY);val y=t+((maxY-v)/(maxY-minY))*(b-t);val x=l+(i.toFloat()/count)*(r-l);if(i==1)path.moveTo(x,y)else path.lineTo(x,y)};c.drawPath(path,line)
        }
    }

    private inner class SpectrumView(ctx:Context):View(ctx) {
        private val grid=Paint( Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(35,57,73); strokeWidth=1f }
        private val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cyan; strokeWidth=3f; style=Paint.Style.STROKE }
        private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=muted; textSize=10f }
        override fun onDraw(c:Canvas) { super.onDraw(c); c.drawColor(Color.rgb(7,19,31)); val left=34f; val right=width-8f; val top=12f; val bottom=height-22f
            // Fixed display range: +60 dB at the top, -60 dB at the bottom.
            for(i in 0..6) { val db=60-i*20; val y=top+(bottom-top)*i/6f; c.drawLine(left,y,right,y,grid); c.drawText("${db} dB",2f,y-2,text) }
            val freqs=listOf("20","100","1k","10k","20k"); for(i in 0..4) { val x=left+(right-left)*i/4f; c.drawLine(x,top,x,bottom,grid); c.drawText(freqs[i],x-8,bottom+15,text) }
            val mags=latestSpectrum; if(mags.size<4) return
            val path=Path(); val count= min(500,mags.size-1); for(i in 1..count) { val norm=i.toFloat()/count; val db=(20*log10(max(1e-6f,mags[i]))).coerceIn(-60f,60f); val y=top+((60f-db)/120f)*(bottom-top); val x=left+norm*(right-left); if(i==1) path.moveTo(x,y) else path.lineTo(x,y) }; c.drawPath(path,line)
        }
    }
}
