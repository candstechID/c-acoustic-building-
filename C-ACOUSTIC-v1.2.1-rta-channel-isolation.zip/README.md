# C ACOUSTIC v1.1.0 — Persistent Signal Generator

Change: Signal Generator keeps running when navigating between RTA, Transfer Function, Impulse Response, Settings, and other in-app pages. It stops when the user explicitly switches the generator OFF, when changing signal type (restarts as needed), when the Activity is paused/backgrounded, or when the app is destroyed.

Build: Open this Android project in Android Studio and build the debug APK. Requires JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.7.3 / Gradle 8.9, CMake 3.22.1, and Android NDK.

Note: This source ZIP has not been compiled or tested on a physical device in this environment.
