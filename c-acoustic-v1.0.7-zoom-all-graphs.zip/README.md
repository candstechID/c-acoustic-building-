# C ACOUSTIC — CANDSTECH v1.0.7

Pembaruan zoom untuk seluruh grafik: RTA, Impulse Response, semua panel Transfer Function (Time Response, Phase, Frequency + Coherence), serta grafik preview capture/target yang menggunakan komponen grafik bersama.

- Pinch-to-zoom 1x–5x di semua komponen grafik.
- Ketuk dua kali pada grafik untuk mengembalikan zoom ke 1x.
- Tombol dan tata letak versi sebelumnya dipertahankan.

## Build
Buka proyek ini di Android Studio dengan JDK 17, Android SDK Platform 35, Android NDK, dan CMake 3.22.1. Jalankan `assembleDebug` atau gunakan workflow GitHub Actions.

Package: `com.candstech.cacoustic`
Version: `1.0.7` (versionCode 107)

Catatan: source ZIP diperbarui; APK belum dibangun atau diuji pada perangkat dalam sesi ini.
