# C ACOUSTIC v1.2.5 — Frequency Axis, Capture Reference, Auto Phase & Target Curve

## Changes
- Transfer magnitude and phase plots use the same logarithmic frequency mapping (20 Hz to min(Nyquist, 20 kHz)); labels and data bins now share the same frequency-to-x transform.
- RTA capture preview uses the same logarithmic frequency mapping, instead of drawing linearly spaced FFT bins beneath logarithmic labels.
- Capture Manager now displays selected saved magnitude spectrum and a separate live TF phase reference plot.
- Auto Phase action in Capture Manager can estimate the phase slope from live TF bins whose coherence is at least 0.5, and enables the phase-delay correction path. It requires an active two-channel Transfer measurement and sufficient valid bins.
- Target curve choices (Flat Response, House Curve, Speech Tilt) can be toggled and drawn over the capture magnitude preview.
- Version bumped to 1.2.5.

## Validation status
- ZIP integrity should be checked after packaging.
- Android APK build and physical loopback validation are not claimed here. The Capture Manager magnitude plot is based on the selected saved spectrum; the phase panel is a live TF reference, not historical phase stored with each capture.
- Target curves are visual references only. Speech Tilt is an approximate curve, not a standards-accurate ISO 226 equal-loudness curve, and should not be used as an automatic EQ recommendation.
- Auto Phase should be verified using a known loopback delay before critical alignment use.
