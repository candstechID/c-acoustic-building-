# C ACOUSTIC — CANDSTECH v1.0.4

Pembaruan UI Transfer Function:
- Menghapus keterangan panjang di bawah kontrol Capture.
- Tombol TRANSFER ON/OFF dan CAPTURE disejajarkan dalam satu baris dengan ukuran lebih ringkas.
- Ketiga grafik tetap bertumpuk: Time Response (Lin/Log/ETC), Phase, serta Magnitude + Coherence.
- Area grafik diperbesar agar lebih mudah dibaca pada orientasi landscape.
- Mendukung pinch-to-zoom pada setiap grafik (rentang visual 1x–3x).

## Build
Buka proyek ini di Android Studio dengan JDK 17, Android SDK Platform 35, Android NDK, dan CMake 3.22.1. Jalankan Gradle task `assembleDebug` atau gunakan workflow GitHub Actions yang tersedia.

Package: `com.candstech.cacoustic`
Version: `1.0.4` (versionCode 104)

Catatan: source ZIP telah diperiksa integritas arsipnya; APK belum dibangun atau diuji di perangkat pada sesi ini.
