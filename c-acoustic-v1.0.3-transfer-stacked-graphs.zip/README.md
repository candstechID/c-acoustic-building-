# C ACOUSTIC — CANDSTECH v1.0.3

Pembaruan UI Transfer Function:
- Menghapus tombol tab terpisah Magnitude, Phase, dan Coherence.
- Menampilkan tiga grafik bertumpuk: Time Response (Lin/Log/ETC), Phase, serta Magnitude + Coherence (garis coherence merah).
- Hanya satu tombol TRANSFER ON / OFF untuk mulai dan menghentikan pengukuran.
- Tombol CAPTURE tetap terpisah untuk menyimpan snapshot.
- Label input diringkas agar ruang grafik lebih luas pada orientasi landscape.

## Build
Buka proyek ini di Android Studio dengan JDK 17, Android SDK Platform 35, Android NDK, dan CMake 3.22.1. Jalankan Gradle task `assembleDebug` atau gunakan workflow GitHub Actions yang tersedia.

Package: `com.candstech.cacoustic`
Version: `1.0.3` (versionCode 103)
