# C ACOUSTIC technical roadmap

## Phase 1 — Foundation (current scaffold)
- Kotlin dashboard and navigation
- JNI bridge / CMake / native C++ DSP examples
- FFT magnitude, RMS and integer-lag cross-correlation test helpers

## Phase 2 — Audio I/O
- USB device enumeration and permission lifecycle
- Evaluate Android USB Audio Class compatibility and native audio backend
- Select AAudio/Oboe where appropriate; retain fallback strategy only where supported
- Dual-channel capture, format negotiation, ring buffers, drop/overrun detection
- Verify reference and measurement channels share a clock

## Phase 3 — Measurement engine
- RTA with configurable FFT size, window, averaging, smoothing and peak hold
- Transfer function via cross spectra, magnitude, phase, coherence and stable reference
- IR capture with excitation, windowing, timing and quality checks
- SPL calibration profiles and weighting/time averaging

## Phase 4 — Auto Phase
- Capture TF1 (main) and TF2 (sub) using consistent measurement geometry and reference
- Estimate coarse lag using correlation; refine with fractional-delay interpolation
- Optimize complex summation in the selected crossover band, including polarity candidates
- Present confidence, recommended delay and before/after verification
- Do not directly change external DSP unless an explicit supported control protocol exists

## Phase 5 — Validation
- Unit tests with generated sine, impulse and known-delay signals
- Reference comparisons against established measurement equipment/software
- Hardware matrix across Android models and USB interfaces
- Document measurement uncertainty, latency and supported combinations

## Real-time constraints
No heap allocations, blocking I/O, file access or UI calls on the audio callback. Use preallocated buffers and bounded work. Measure callback duration and count dropped frames.

## Capture Manager / Target Curve Advisor (UI scaffold)
The app now exposes a Capture tab describing the intended saved-capture workflow and target choices (ISO 226 equal-loudness at 80 phon, House Curve, Flat Response). This UI is not yet a functional capture database or EQ optimizer. Next implementation steps:
1. Persist raw/complex capture data with sample rate, channel mapping, timestamp, calibration metadata, and measurement reference.
2. Integrate validated ISO 226:2023 equal-loudness values and interpolation; explicitly flag frequencies outside the standard table's supported range.
3. Compute target error per frequency and optimize realizable parametric EQ filters with boost/cut, Q, and headroom limits.
4. Predict response from the measured response plus complex filter response; label as prediction until verified by remeasurement.
5. Validate with synchronized two-channel interface and calibrated measurement microphone.
