# C ACOUSTIC v1.2.5 — Frequency Axis, Capture Reference, Auto Phase & Target Curve

## Changes
- Transfer magnitude and phase plots use the same logarithmic frequency mapping (20 Hz to min(Nyquist, 20 kHz)); labels and data bins now share the same frequency-to-x transform.
- RTA capture preview uses the same logarithmic frequency mapping, instead of drawing linearly spaced FFT bins beneath logarithmic labels.
- Capture Manager now displays selected saved magnitude spectrum and a separate live TF phase reference plot.
- Auto Phase action in Capture Manager can estimate the phase slope from live TF bins whose coherence is at least 0.5, and enables the phase-delay correction path. It requires an active two-channel Transfer measurement and sufficient valid bins.
- Target curve choices (Flat Response, House Curve, Speech Tilt) can be toggled and drawn over the capture magnitude preview.
- Version bumped to 1.2.5.

## Validation status
- ZIP integrity should be checked after packaging.
- Android APK build and physical loopback validation are not claimed here. The Capture Manager magnitude plot is based on the selected saved spectrum; the phase panel is a live TF reference, not historical phase stored with each capture.
- Target curves are visual references only. Speech Tilt is an approximate curve, not a standards-accurate ISO 226 equal-loudness curve, and should not be used as an automatic EQ recommendation.
- Auto Phase should be verified using a known loopback delay before critical alignment use.


## v1.3.4 — Shared frequency-axis pass
- RTA/live spectrum and saved Capture spectrum use a consistent logarithmic 10 Hz–22 kHz axis with anchor labels (10, 31.5, 63, 125, 250, 500, 1k, 2k, 4k, 8k, 16k, 22k).
- Transfer Function magnitude/phase retains the same log-axis anchors.
- Impulse Response remains a time-domain plot (ms), as frequency labels would be physically incorrect for an impulse/time graph. Its spectrum/TF views use the frequency axis when those views are shown.
- Max frequency is capped by Nyquist (sampleRate/2); labels above the available Nyquist frequency are omitted.

Build status: source archive only; no Android SDK/Gradle wrapper available in this workspace to run assembleDebug. DSP accuracy still requires loopback tests with known amplitude, frequency and delay.

## v1.3.5 — tab header and fixed Settings title
- The selected tab title is centered in the fixed top bar, with the original CANDSTECH logo immediately beside it.
- The title/logo group stays centered in the same position when switching tabs; it does not participate in the scrolling content.
- On the Settings tab, the fixed header keeps “SETTINGS” visible while the settings options scroll below it.
- Android build has not been run in this environment; validate with the project GitHub Actions workflow before treating an APK as verified.


## v1.3.6 — header aman dari status bar
- Header utama (judul tab aktif dan logo CANDSTECH) diberi jarak atas 28dp agar berada di bawah status bar pada orientasi landscape.
- Judul dan logo tetap satu kelompok terpusat di area konten utama.
- Header berada di luar ScrollView, sehingga judul Settings tetap terlihat saat isi pengaturan digulir.
- APK belum dibangun atau diuji di perangkat; periksa tampilan pada perangkat target.

## v1.3.7 — centered fixed title/logo header
- Removed the short blue navigation label (RTA/Transfer/etc.) from the top header.
- The fixed header now centers the CANDSTECH logo beside the active page's descriptive white title (REALTIME ANALYZER, TRANSFER FUNCTION, etc.).
- Reduced arbitrary top padding; Android system status-bar handling remains controlled by the window/system UI.
- Source changes are not an APK build; validate visually on the target device.


## v1.3.8 — Ukuran logo header
- Ukuran kotak logo di header kedua diperbesar dari 104×42 dp menjadi 120×48 dp agar lebih seimbang dengan judul putih.
- Posisi gabungan logo dan judul tetap dipusatkan; judul tab biru di header pertama tetap tidak ditampilkan.
- Belum dibuild atau diuji pada perangkat Android.

## v1.3.9 — plot watermark and simplified header
- Moved the CANDSTECH logo out of the fixed header and into the plot backgrounds as a large, centered low-opacity watermark (alpha 26/255).
- Applied watermark rendering to RTA spectrum, TF graphs, IR/time-response graph, Auto Phase graph, and Capture phase/spectrum graphs. Curves and measurement overlays are drawn after the watermark so they remain in front.
- Kept the active page title centered in the fixed header; no short blue tab name is displayed there.
- Build status: not compiled or device-tested in this environment; verify APK rendering and performance on device before release.


## v1.4.0 — Header branding only
- Removed the page-specific title from the fixed top header on every tab.
- The header now shows only “C Acoustic by candstech”, centered.
- Graph watermark behavior from v1.3.9 remains enabled across supported plots.
- Source archive checked for ZIP integrity; Android build/device testing has not been run.


## v1.4.1 — Auto Phase guidance and larger watermark
- Auto Phase results now separate the recommendation into DELAY and POLARITY, with a suggested target path (MIC/measurement relative to REF) and a reminder to change one parameter at a time and recapture.
- Polarity indicator uses a circular phase mean rather than a simple arithmetic mean. It remains an advisory, not an automatic invert command.
- Graph watermark enlarged to use more of the graph area and made slightly more visible while drawing traces above it.
- Source archive integrity checked; Android build/device test not run.


## v1.4.2 — Compare two selected TF captures
- Auto Phase now requires two selected Transfer captures and compares their stored phase/coherence, instead of estimating alignment from a single capture or referring to a mic path.
- Fits the unwrapped phase difference versus frequency to estimate relative delay; names the slower capture and the faster capture that should receive the additional delay, with the amount in milliseconds and equivalent phase degrees at 1 kHz.
- Uses shared bins where both captures have coherence >= 0.5 and requires at least 12 bins. Result is relative and assumes matching routing, sample rate, FFT settings, and measurement conditions.
- Build/device verification has not been run.

## v1.4.3 — Audio latency tuning (experimental)
- Requests Android AudioTrack low-latency performance mode for generator output.
- Reduces oversized output buffering and capture buffer targets while keeping at least 2x platform minimum buffer and enough room for FFT frame reads.
- Prefers a detected USB input for AudioRecord and USB output for AudioTrack when Android exposes one. Routing is a preference, not a guarantee; verify the active route on the target device.
- This does not provide zero latency. Android, USB interface firmware/driver, sample-rate conversion, output/input buffering, and acoustic propagation all add delay. Capture/TF timing must be validated with a loopback measurement.
- Build and device testing have not been performed in this environment. Low-latency mode is a request; unsupported devices may ignore it or need a larger buffer to avoid dropouts.
