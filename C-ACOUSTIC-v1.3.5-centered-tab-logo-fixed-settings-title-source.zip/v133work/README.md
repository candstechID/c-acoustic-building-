# C ACOUSTIC v1.2.5 — Frequency Axis, Capture Reference, Auto Phase & Target Curve

## Changes
- Transfer magnitude and phase plots use the same logarithmic frequency mapping (20 Hz to min(Nyquist, 20 kHz)); labels and data bins now share the same frequency-to-x transform.
- RTA capture preview uses the same logarithmic frequency mapping, instead of drawing linearly spaced FFT bins beneath logarithmic labels.
- Capture Manager now displays selected saved magnitude spectrum and a separate live TF phase reference plot.
- Auto Phase action in Capture Manager can estimate the phase slope from live TF bins whose coherence is at least 0.5, and enables the phase-delay correction path. It requires an active two-channel Transfer measurement and sufficient valid bins.
- Target curve choices (Flat Response, House Curve, Speech Tilt) can be toggled and drawn over the capture magnitude preview.
- Version bumped to 1.2.5.

## Validation status
- ZIP integrity should be checked after packaging.
- Android APK build and physical loopback validation are not claimed here. The Capture Manager magnitude plot is based on the selected saved spectrum; the phase panel is a live TF reference, not historical phase stored with each capture.
- Target curves are visual references only. Speech Tilt is an approximate curve, not a standards-accurate ISO 226 equal-loudness curve, and should not be used as an automatic EQ recommendation.
- Auto Phase should be verified using a known loopback delay before critical alignment use.


## v1.3.4 — Shared frequency-axis pass
- RTA/live spectrum and saved Capture spectrum use a consistent logarithmic 10 Hz–22 kHz axis with anchor labels (10, 31.5, 63, 125, 250, 500, 1k, 2k, 4k, 8k, 16k, 22k).
- Transfer Function magnitude/phase retains the same log-axis anchors.
- Impulse Response remains a time-domain plot (ms), as frequency labels would be physically incorrect for an impulse/time graph. Its spectrum/TF views use the frequency axis when those views are shown.
- Max frequency is capped by Nyquist (sampleRate/2); labels above the available Nyquist frequency are omitted.

Build status: source archive only; no Android SDK/Gradle wrapper available in this workspace to run assembleDebug. DSP accuracy still requires loopback tests with known amplitude, frequency and delay.

## v1.3.5 — tab header and fixed Settings title
- The selected tab title is centered in the fixed top bar, with the original CANDSTECH logo immediately beside it.
- The title/logo group stays centered in the same position when switching tabs; it does not participate in the scrolling content.
- On the Settings tab, the fixed header keeps “SETTINGS” visible while the settings options scroll below it.
- Android build has not been run in this environment; validate with the project GitHub Actions workflow before treating an APK as verified.
