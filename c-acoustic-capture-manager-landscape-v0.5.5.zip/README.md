# C ACOUSTIC — Android audio measurement scaffold

C ACOUSTIC by CANDSTECH is an Android-native starter for a professional audio measurement application.

## Included
- Kotlin dashboard with tabs for RTA, Transfer Function, Impulse Response, SPL Meter, Audio I/O and Auto Phase.
- Native C++ DSP primitives: Hann window, radix-2 FFT, basic RMS, cross-correlation delay estimate and a fractional-delay candidate helper.
- CMake/NDK JNI bridge.
- GitHub Actions workflow for extracting an uploaded source ZIP into the repository.
- Architecture notes and validation checklist.

## Important status
This is a substantially expanded **prototype scaffold**, not a validated professional measurement instrument. USB audio capture/routing, calibrated SPL, synchronized dual-channel capture, frequency-dependent transfer function/coherence, full IR acquisition, and actual external DSP control still require implementation and hardware testing. The Auto Phase screen is a demonstration of recommendations only; it does not control a mixer/DSP.

## Build
Open this folder in Android Studio (JDK 17). Install Android SDK Platform 35, NDK, and CMake 3.22.1 via SDK Manager, sync Gradle, then Run. Gradle wrapper is not included.

## GitHub ZIP workflow
The workflow must already be committed at `.github/workflows/extract-uploaded-zip.yml` before uploading `c-acoustic-android-source.zip`. Upload the ZIP to the repository root, commit it, then go to Actions → Extract uploaded source ZIP → Run workflow. It safely extracts the archive, removes the archive from the working tree, and commits the source files.

## DSP limitations
The FFT implementation is a basic radix-2 educational primitive. It is not a substitute for calibration, window/averaging design, coherent capture, or validated transfer-function algorithms. Validate all results against known signals and reference equipment before relying on them for live PA tuning.


## RTA level scale
RTA graph is set to a fixed visual range from +60 dB at the top to -60 dB at the bottom. Note: the underlying live signal is still shown as dBFS; positive dBFS is not a physically valid digital level, so this ±60 display is a requested visual scale, not SPL calibration.


## Milestone 0.3.0
- RTA live microphone capture with native FFT and fixed display scale from +60 dB to -60 dB.
- SPL page includes a manually adjustable offset saved on device and live relative estimate.
- Important: the default offset is only a placeholder, not a calibration. Compare with a trusted SPL meter/calibrator before relying on readings.
- Transfer Function, full Impulse Response and Auto Phase remain planned; they require synchronized input and further implementation/testing.

## Transfer Function (prototype v0.4.0)

The Transfer page now attempts Android stereo PCM capture at 48 kHz, treats channel 1 as reference and channel 2 as measurement, computes averaged cross/auto spectra through the native DSP layer, and exposes magnitude, phase, and coherence plots. This is a prototype implementation, not a validated measurement instrument. Android may supply mono, processed, or internally mixed channels even when a stereo recording request succeeds. Use a USB interface that exposes two independent synchronous input channels and verify channel routing with a known electrical loopback before trusting results. Coherence/magnitude require further bench validation, calibration, and testing on target devices.


## v0.5.1 Signal Generator

Added a Signal tab with ON/OFF controls for pink noise and a repeating logarithmic 20 Hz–20 kHz sweep. Playback is streamed through Android AudioTrack at a nominal 48 kHz mono output, with conservative digital amplitude. Actual output level depends on device, volume, DAC/interface, and routing; it is not calibrated. Stop the signal before changing routing and begin at low volume.


Signal Generator UI v0.5.1: pilih Pink Noise atau Pink Sweep sebagai mode, lalu gunakan satu tombol ON/OFF untuk memulai atau menghentikan generator.

## v0.5.2 UI scaffold — Capture Manager & Target Curve Advisor
- Added a Capture tab with the intended workflow for selecting saved measurements, reviewing measured/target/predicted curves, and opening Auto Phase.
- Added target choices: ISO 226 equal-loudness (80 phon), House Curve, and Flat Response.
- Important: this is a UI/roadmap scaffold, not a completed analysis engine. Capture persistence, validated ISO 226 data, actual target interpolation, filter optimization, and measured-vs-predicted response still need implementation and device testing. The app explicitly tells users when capture storage is not implemented.


## v0.5.3 - Capture Manager + portrait
- Activity dikunci portrait.
- Capture Manager dapat menyimpan snapshot spektrum RTA, menampilkan daftar capture, multi-select, preview spektrum terpilih, dan menghapus capture terpilih.
- Capture disimpan lokal di SharedPreferences, maksimum 10 hasil.
- Auto Phase tetap memerlukan capture dua kanal yang tersinkron; snapshot spektrum RTA tidak menyimpan fase/delay.
- Build belum diverifikasi pada Android SDK di sesi ini.

## v0.5.4 Capture buttons and Settings
- Added save-capture snapshot buttons on RTA, Transfer Function, and Impulse Response pages.
- Added a Settings page for FFT size, sample-rate preference, averaging, window, smoothing, SPL calibration shortcut, and Audio I/O shortcut.
- Portrait orientation remains enforced.
- Important limitation: FFT size, sample-rate preference, averaging, window and smoothing are currently stored as settings but are not all wired into the DSP pipeline yet. Capture storage is a snapshot prototype; IR capture is not yet a validated impulse-response acquisition pipeline. Transfer snapshots save current TF magnitude only; phase/coherence and synchronized metadata are not stored in the capture format yet.


## v0.5.5 changes
- Main activity locked to landscape orientation.
- Removed standalone Auto Phase tab; Auto Phase action is shown inside Capture Manager.
- Auto Phase remains a guarded placeholder until synchronized phase/IR capture is implemented; no delay or polarity result is fabricated.
