# C ACOUSTIC v1.1.0 — Persistent Signal Generator

Change: Signal Generator keeps running when navigating between RTA, Transfer Function, Impulse Response, Settings, and other in-app pages. It stops when the user explicitly switches the generator OFF, when changing signal type (restarts as needed), when the Activity is paused/backgrounded, or when the app is destroyed.

Build: Open this Android project in Android Studio and build the debug APK. Requires JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.7.3 / Gradle 8.9, CMake 3.22.1, and Android NDK.

Note: This source ZIP has not been compiled or tested on a physical device in this environment.


## v1.2.2 source patch (experimental)
- Adds normalized, mean-removed lag correlation over a rolling ~300 ms history for TF delay estimation.
- Rejects low-correlation estimates rather than assigning a confidence of 1.0 unconditionally.
- Updates Android version metadata to 1.2.2 / versionCode 122.
- This is a source patch; full Android APK build and acoustic validation are still required. Check phase-compensation polarity with a known loopback before relying on it for alignment.
