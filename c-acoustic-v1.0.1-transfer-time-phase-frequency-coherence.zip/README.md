# C ACOUSTIC v1.0.1 — Transfer Layout Update

Transfer Function page layout update:
- Top plot: Time Response panel with Lin / Log / ETC display-mode selector.
- Middle plot: Phase response (degrees).
- Bottom plot: Frequency response (dB) with coherence overlaid in red on an independent 0–1 scale.
- Transfer measurement ON/OFF and Capture snapshot controls remain separate.
- Landscape orientation retained.

Important limitation: the Time Response selector and axis presentation are UI controls only in this revision. A synchronized impulse-response/time-domain data pipeline is not yet implemented, so the top plot explicitly indicates that time/IR data has not been captured. The Frequency/Coherence curves depend on live two-channel capture; they are not simulated measurements.

## Build
Open this project in Android Studio or use the included GitHub Actions workflow to build a debug APK. This source ZIP has not been compiled or device-tested in this environment; do not treat it as a verified production APK.
