# C ACOUSTIC v1.0.9 — Global Input Routing

## Global Reference / Mic channel settings
Settings provides one persistent global configuration for Reference CH 1/CH 2 and Mic/Measurement CH 1/CH 2.

- RTA, Impulse page capture, and SPL use the selected Mic/Measurement channel when Android exposes a stereo input stream.
- Transfer Function uses both selected Reference and Mic channels.
- Signal Generator uses the output path and is not affected by input channel selection.
- If the audio device only exposes mono input, channel 2 cannot physically be selected; mono fallback uses channel 1.

The routing is implemented in the audio capture path, not just as labels. Hardware-specific channel order and external USB interface behavior still require validation on the target device. This source ZIP has not been compiled into an APK in this environment.
