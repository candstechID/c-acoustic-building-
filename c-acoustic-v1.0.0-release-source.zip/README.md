# C ACOUSTIC v1.0.0 — Release Source

Release source package for the C ACOUSTIC Android audio analyzer prototype.

## Release changes
- One ON/OFF toggle per measurement feature (RTA, Transfer Function, Impulse Response, SPL, and Signal Generator). Capture snapshot actions remain separate.
- Landscape orientation remains locked.
- Existing CANDSTECH logo, capture, and audio settings source retained.

## Build APK
Upload this ZIP to the repository that contains the provided GitHub Actions workflow, then run **Actions → Build C Acoustic from uploaded ZIP → Run workflow**. Download the `c-acoustic-debug-apk` artifact if the workflow succeeds.

## Important status
This is a **release source ZIP**, not a verified APK. Transfer Function requires a genuine two-channel audio input with a shared clock. Hardware compatibility, measurement accuracy, and full device testing remain unverified. Do not treat this prototype as calibrated professional measurement equipment until validated.
