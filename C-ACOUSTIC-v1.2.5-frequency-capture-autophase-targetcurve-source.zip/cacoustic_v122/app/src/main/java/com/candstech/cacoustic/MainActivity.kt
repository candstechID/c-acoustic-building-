package com.candstech.cacoustic

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.media.AudioFormat
import android.os.Build
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.provider.Settings
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private external fun nativeDspStatus(): String
    private external fun nativeRms(samples: FloatArray): Float
    private external fun nativeEstimateLag(reference: FloatArray, measured: FloatArray, maxLag: Int): Int
    private external fun nativeEstimateLagNormalized(reference: FloatArray, measured: FloatArray, maxLag: Int): FloatArray
    private external fun nativeFftMagnitude(samples: FloatArray): FloatArray
    private external fun nativeTransferFrame(reference: FloatArray, measured: FloatArray, windowType: Int): FloatArray
    companion object { private const val MIC_REQUEST = 41; init { System.loadLibrary("cacoustic_dsp") } }

    private val bg = Color.rgb(5, 14, 25); private val panel = Color.rgb(12, 27, 42)
    private val cyan = Color.rgb(53, 215, 239); private val muted = Color.rgb(151, 177, 196)
    private var selected = "RTA"; private lateinit var content: LinearLayout
    private data class SavedCapture(val id: Long, val name: String, val created: String, val spectrum: FloatArray)
    private val chosenCaptureIds = linkedSetOf<Long>()
    private var captureNameInput: EditText? = null
    private var splOffsetDb = 120f
    private var inputGain = 1.0f
    private var outputGain = 0.25f
    private var settingsFftSize = 4096
    private var settingsSampleRate = 48000
    private var settingsAveraging = 8
    private var settingsSmoothing = "1/3 octave"
    private var settingsWindow = "Hann"
    private var referenceChannel = 1
    private var micChannel = 2
    private var rtaChannel = 1
    @Volatile private var recording = false
    private var audioRecord: AudioRecord? = null
    private var audioThread: Thread? = null
    private var spectrumView: SpectrumView? = null
    private var statusText: TextView? = null
    private var levelText: TextView? = null
    private var transferView: TransferView? = null
    private var transferPhaseView: TransferView? = null
    private var transferStatus: TextView? = null
    @Volatile private var signalRunning = false
    private var signalMode = "Pink Noise"
    private var signalTrack: AudioTrack? = null
    private var signalThread: Thread? = null
    @Volatile private var tfMagnitude = FloatArray(2049)
    @Volatile private var tfPhase = FloatArray(2049)
    @Volatile private var tfCoherence = FloatArray(2049)
    @Volatile private var autoDelayEnabled = false
    @Volatile private var delayTrackerEnabled = false
    @Volatile private var autoPhaseEnabled = false
    @Volatile private var estimatedDelaySamples = 0f
    @Volatile private var delayConfidence = 0f
    private var tfDisplayMode = "Magnitude"
    @Volatile private var targetCurveMode = "Flat Response"
    @Volatile private var targetCurveEnabled = true
    @Volatile private var latestSpectrum = FloatArray(2049)
    @Volatile private var latestRms = 0f
    @Volatile private var latestPeak = 0f

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); splOffsetDb = getPreferences(Context.MODE_PRIVATE).getFloat("spl_offset_db", 120f); inputGain=getPreferences(Context.MODE_PRIVATE).getFloat("input_gain",1.0f); outputGain=getPreferences(Context.MODE_PRIVATE).getFloat("output_gain",0.25f); settingsFftSize=getPreferences(Context.MODE_PRIVATE).getInt("fft_size",4096); settingsSampleRate=getPreferences(Context.MODE_PRIVATE).getInt("sample_rate",48000); settingsAveraging=getPreferences(Context.MODE_PRIVATE).getInt("averaging",8); settingsSmoothing=getPreferences(Context.MODE_PRIVATE).getString("smoothing","1/3 octave") ?: "1/3 octave"; settingsWindow=getPreferences(Context.MODE_PRIVATE).getString("window","Hann") ?: "Hann"; referenceChannel=getPreferences(Context.MODE_PRIVATE).getInt("reference_channel",1).coerceIn(1,2); micChannel=getPreferences(Context.MODE_PRIVATE).getInt("mic_channel",2).coerceIn(1,2); rtaChannel=getPreferences(Context.MODE_PRIVATE).getInt("rta_channel",1).coerceIn(1,2); if(referenceChannel==micChannel) micChannel=if(referenceChannel==1) 2 else 1; window.statusBarColor=bg; window.navigationBarColor=bg; buildShell(); renderPage() }
    override fun onDestroy() { stopCapture(); stopSignal(); super.onDestroy() }
    override fun onPause() { super.onPause(); stopCapture(); stopSignal() }

    private fun buildShell() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(bg); setPadding(8,8,8,8) }
        val sidebar=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(8,22,36)); setPadding(7,8,7,8) }
        sidebar.addView(TextView(this).apply { text="C ACOUSTIC"; textSize=16f; typeface=android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD); setTextColor(cyan); setPadding(3,0,3,0) })
        sidebar.addView(TextView(this).apply { text="AUDIO ANALYSIS • SYSTEM TUNING"; textSize=7f; setTextColor(muted); setPadding(3,0,3,10) })
        listOf("RTA","Transfer","Impulse","SPL","Signal","Capture","Settings","Audio I/O").forEach { tab ->
            val label=when(tab){"Transfer"->"Transfer Function";"Impulse"->"Impulse Response";"Signal"->"Signal Generator";"Audio I/O"->"Audio I/O";else->tab}
            sidebar.addView(Button(this).apply { text=label; textSize=10f; isAllCaps=false; gravity=Gravity.START or Gravity.CENTER_VERTICAL; setPadding(9,4,4,4); minHeight=38; setTextColor(if(tab==selected) cyan else Color.rgb(220,233,243)); setBackgroundColor(if(tab==selected) Color.rgb(15,65,78) else Color.TRANSPARENT); setOnClickListener { stopCapture(); selected=tab; buildShell(); renderPage() } },LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=3 })
        }
        root.addView(sidebar,LinearLayout.LayoutParams(150, -1))
        val main=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(10,0,0,0) }
        val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(4,0,4,3); minimumHeight=58 }
        top.addView(TextView(this).apply { text="C ACOUSTIC"; textSize=12f; typeface=android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD); setTextColor(cyan); maxLines=1 },LinearLayout.LayoutParams(0,-2,1f))
        top.addView(ImageView(this).apply {
            setImageResource(com.candstech.cacoustic.R.drawable.candstech_logo_original)
            scaleType=ImageView.ScaleType.FIT_CENTER
            adjustViewBounds=true
            contentDescription="Logo CANDSTECH"
            setPadding(2,0,2,0)
        }, LinearLayout.LayoutParams(220, 54))
        top.addView(TextView(this).apply { text="● DEVICE AUDIO"; textSize=9f; setTextColor(cyan); gravity=Gravity.END; maxLines=1 },LinearLayout.LayoutParams(0,-2,1f))
        main.addView(top, LinearLayout.LayoutParams(-1, 58))
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,2,0,0) }
        main.addView(ScrollView(this).apply { isFillViewport=true; addView(content) },LinearLayout.LayoutParams(-1,0,1f))
        root.addView(main,LinearLayout.LayoutParams(0,-1,1f)); setContentView(root)
    }
    private fun renderPage() {
        content.removeAllViews(); spectrumView=null; statusText=null; levelText=null; transferView=null; transferStatus=null
        when(selected) {
            "RTA" -> {
                heading("REAL-TIME ANALYZER","Live FFT • satu kanal fisik dipilih, bukan gabungan CH1+CH2")
                action("RTA INPUT: CH $rtaChannel  •  GANTI KE CH ${if(rtaChannel==1) 2 else 1}") { if(recording) stopCapture(); rtaChannel=if(rtaChannel==1) 2 else 1; getPreferences(Context.MODE_PRIVATE).edit().putInt("rta_channel",rtaChannel).apply(); renderPage() }
                metric("FFT SIZE",settingsFftSize.toString(),"Resolusi frekuensi mengikuti sample rate ${settingsSampleRate} Hz")
                graphBox("RTA SPECTRUM", 320)
                levelText=TextView(this).apply { text="Level: —"; textSize=14f; setTextColor(cyan); setPadding(4,8,4,8) }; content.addView(levelText)
                statusText=TextView(this).apply { text="Mikrofon belum aktif"; textSize=11f; setTextColor(muted); setPadding(4,4,4,8) }; content.addView(statusText)
                compactActionRow(if (recording) "⏻ RTA ON" else "⏻ RTA OFF", "CAPTURE", {
                    if (recording) { stopCapture(); statusText?.text="RTA OFF • Capture dihentikan" }
                    else requestMicAndStart()
                    renderPage()
                }, { saveCurrentCapture() })
            }
            "Transfer" -> {
                heading("TRANSFER FUNCTION", "Dual-channel • H1 estimate • magnitude / phase / coherence")
                content.addView(TextView(this).apply {
                    text = "GLOBAL ROUTING • REF CH $referenceChannel  /  MIC CH $micChannel"
                    textSize = 10f; setTextColor(muted); setPadding(4, 0, 4, 5)
                })
                // Three stacked analyzer plots: selectable time-domain view, phase, and frequency with coherence overlay.
                val plots=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(6,6,6,6) }
                val timeHeader=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
                timeHeader.addView(TextView(this).apply { text="TIME RESPONSE  •  Lin / Log / ETC"; setTextColor(Color.WHITE); textSize=11f; setPadding(4,3,4,0) },LinearLayout.LayoutParams(0,-2,1f))
                val timeMode=Spinner(this)
                val timeModes=listOf("Lin","Log","ETC")
                timeMode.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,timeModes)
                timeMode.setSelection(0)
                timeHeader.addView(timeMode,LinearLayout.LayoutParams(100,-2))
                plots.addView(timeHeader)
                val timePlot=TimeResponseView(this)
                plots.addView(timePlot,LinearLayout.LayoutParams(-1,190).apply { topMargin=2; bottomMargin=3 })
                timeMode.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(parent:android.widget.AdapterView<*>?) {}
                    override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long) { timePlot.displayMode=timeModes[position]; timePlot.invalidate() }
                }
                val phasePlot=TransferView(this,"Phase")
                val frequencyPlot=TransferView(this,"Frequency+Coherence")
                transferPhaseView=phasePlot
                transferView=frequencyPlot
                fun addTfPlot(title:String, plot:View, heightDp:Int) {
                    plots.addView(TextView(this).apply { text=title; setTextColor(Color.WHITE); textSize=11f; setPadding(4,3,4,0) })
                    plots.addView(plot,LinearLayout.LayoutParams(-1,heightDp).apply { topMargin=2; bottomMargin=5 })
                }
                addTfPlot("PHASE (°)",phasePlot,190)
                addTfPlot("MAGNITUDE (dB)  +  COHERENCE (red)",frequencyPlot,205)
                content.addView(plots,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 })
                val autoRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
                fun autoButton(label:String, active:Boolean, click:()->Unit)=Button(this).apply { text=label; textSize=9f; isAllCaps=false; minHeight=34; setTextColor(if(active) Color.WHITE else cyan); setBackgroundColor(if(active) Color.rgb(15,65,78) else panel); setOnClickListener { click(); renderPage() } }
                autoRow.addView(autoButton(if(autoDelayEnabled) "AUTO DELAY: ON" else "AUTO DELAY", autoDelayEnabled) { autoDelayEnabled=!autoDelayEnabled; if(!autoDelayEnabled) delayTrackerEnabled=false }, LinearLayout.LayoutParams(0,38,1f))
                autoRow.addView(autoButton(if(delayTrackerEnabled) "TRACKER: ON" else "DELAY TRACKER", delayTrackerEnabled) { delayTrackerEnabled=!delayTrackerEnabled; if(delayTrackerEnabled) autoDelayEnabled=true }, LinearLayout.LayoutParams(0,38,1f))
                autoRow.addView(autoButton(if(autoPhaseEnabled) "AUTO PHASE: ON" else "AUTO PHASE", autoPhaseEnabled) { autoPhaseEnabled=!autoPhaseEnabled; if(autoPhaseEnabled) autoDelayEnabled=true }, LinearLayout.LayoutParams(0,38,1f))
                content.addView(autoRow, LinearLayout.LayoutParams(-1,40).apply { bottomMargin=2 })
                transferStatus=TextView(this).apply { text="Belum ada capture dua kanal"; textSize=12f; setTextColor(cyan); setPadding(4,6,4,10) }; content.addView(transferStatus)
                val transferButtons = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, 2, 0, 2)
                }
                fun compactTfButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
                    text = label
                    textSize = 10f
                    minHeight = 34
                    minimumHeight = 34
                    minWidth = 0
                    isAllCaps = false
                    setPadding(6, 0, 6, 0)
                    setTextColor(cyan)
                    setOnClickListener { onClick() }
                }
                transferButtons.addView(compactTfButton(if (recording) "⏻ TRANSFER ON" else "⏻ TRANSFER OFF") {
                    if (recording) {
                        stopCapture()
                        transferStatus?.text = "Pengukuran dihentikan"
                        renderPage()
                    } else {
                        requestMicAndStartTransfer()
                    }
                }, LinearLayout.LayoutParams(0, 38, 1f).apply { rightMargin = 5 })
                transferButtons.addView(compactTfButton("CAPTURE") { saveCurrentCapture() },
                    LinearLayout.LayoutParams(0, 38, 0.72f))
                content.addView(transferButtons, LinearLayout.LayoutParams(-1, 42).apply { bottomMargin = 2 })
            }
            "Impulse" -> {
                heading("IMPULSE RESPONSE","Arrival time & delay analysis")
                graphBox("IMPULSE RESPONSE", 320)
                compactActionRow(if (recording) "⏻ IR ON" else "⏻ IR OFF", "CAPTURE", {
                    if (recording) stopCapture() else requestMicAndStart()
                    renderPage()
                }, { saveCurrentCapture() })
            }
            "SPL" -> {
                heading("SPL METER", "Relative level • manual reference calibration")
                metric("CALIBRATION OFFSET", String.format(java.util.Locale.US, "%.1f dB", splOffsetDb), "Offset awal hanya perkiraan; kalibrasikan dengan sound level calibrator atau meter referensi.")
                val input = EditText(this).apply {
                    setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                    hint = "Offset dB (mis. 120.0)"; setText(String.format(java.util.Locale.US, "%.1f", splOffsetDb)); setTextColor(Color.WHITE); setHintTextColor(muted); setBackgroundColor(panel)
                }
                content.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
                action("Save calibration offset") {
                    val value = input.text.toString().toFloatOrNull()
                    if (value == null || value !in 0f..200f) Toast.makeText(this, "Masukkan offset 0–200 dB", Toast.LENGTH_LONG).show()
                    else { splOffsetDb = value; getPreferences(Context.MODE_PRIVATE).edit().putFloat("spl_offset_db", value).apply(); Toast.makeText(this, "Offset tersimpan. Verifikasi dengan meter referensi.", Toast.LENGTH_LONG).show(); renderPage() }
                }
                levelText = TextView(this).apply { text = "SPL: menunggu capture"; textSize = 20f; setTextColor(cyan); setPadding(4, 12, 4, 8) }; content.addView(levelText)
                statusText = TextView(this).apply { text = "Belum ada capture"; textSize = 11f; setTextColor(muted); setPadding(4, 4, 4, 8) }; content.addView(statusText)
                action(if (recording) "⏻ SPL ON • TAP TO TURN OFF" else "⏻ SPL OFF • TAP TO TURN ON") { if (recording) { stopCapture(); statusText?.text = "SPL OFF • Capture dihentikan" } else requestMicAndStart(); renderPage() }
                info("SPL dihitung sebagai dBFS + offset manual. Ini belum menerapkan weighting A/C, response time, sensitivitas mikrofon, atau sertifikasi akurasi. Jangan anggap sebagai SPL terkalibrasi tanpa pembandingan alat referensi.")
            }
            "Signal" -> {
                heading("SIGNAL GENERATOR", "Pilih jenis sinyal, lalu ON/OFF")
                metric("AUDIO OUTPUT", "Pink Noise • Pink Sweep", "Sinyal dikirim ke output audio Android yang aktif, termasuk USB DAC jika didukung.")
                content.addView(TextView(this).apply {
                    text = "SIGNAL TYPE"
                    textSize = 11f
                    setTextColor(muted)
                    setPadding(4, 8, 4, 4)
                })
                val choices = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                choices.addView(Button(this).apply {
                    text = "Pink Noise"
                    isAllCaps = false
                    setTextColor(if (signalMode == "Pink Noise") cyan else Color.WHITE)
                    setBackgroundColor(if (signalMode == "Pink Noise") Color.rgb(20,55,69) else panel)
                    setOnClickListener {
                        if (signalRunning) stopSignal()
                        signalMode = "Pink Noise"
                        renderPage()
                    }
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 6 })
                choices.addView(Button(this).apply {
                    text = "Pink Sweep"
                    isAllCaps = false
                    setTextColor(if (signalMode == "Pink Sweep") cyan else Color.WHITE)
                    setBackgroundColor(if (signalMode == "Pink Sweep") Color.rgb(20,55,69) else panel)
                    setOnClickListener {
                        if (signalRunning) stopSignal()
                        signalMode = "Pink Sweep"
                        renderPage()
                    }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                content.addView(choices)
                statusText=TextView(this).apply {
                    text = if (signalRunning) "$signalMode aktif" else "$signalMode siap • Generator OFF"
                    textSize = 14f
                    setTextColor(cyan)
                    setPadding(4, 12, 4, 10)
                }
                content.addView(statusText)
                action(if (signalRunning) "OFF • Stop Generator" else "ON • Start Generator") {
                    if (signalRunning) {
                        stopSignal()
                        statusText?.text = "$signalMode • Generator OFF"
                    } else {
                        startSignal(signalMode == "Pink Sweep")
                    }
                }
                info("Pilih Pink Noise atau Pink Sweep, lalu tekan ON. Tekan OFF untuk menghentikan output. Pink Sweep berjalan logaritmik 20 Hz–20 kHz dan berulang sekitar 10 detik. Mulai dengan volume rendah; output level belum dikalibrasi.")
            }
            "Capture" -> renderCaptureManager()
            "Settings" -> renderSettings()
            "Audio I/O" -> { heading("AUDIO DEVICE & ROUTING","Android input devices • USB/OTG where supported"); action("Refresh audio devices") { listAudioDevices() }; action("Open Android sound settings") { startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }; info(nativeDspStatus()); listAudioDevices() }
            else -> { selected="RTA"; renderPage() }
        }
        content.addView(TextView(this).apply { text="C ACOUSTIC • LANDSCAPE • LIVE RTA PROTOTYPE • DSP VALIDATION REQUIRED"; textSize=9f; setTextColor(muted); setPadding(0,18,0,8) })
    }
    private fun renderSettings() {
        heading("MEASUREMENT SETTINGS", "Parameter konfigurasi C ACOUSTIC")
        heading("GLOBAL INPUT CHANNEL ROUTING", "Satu pengaturan untuk RTA, IR, SPL, dan Transfer Function")
        metric("REFERENCE INPUT", "CH $referenceChannel", "Sinyal referensi / loopback dari output sistem")
        action("REFERENCE CHANNEL • CH $referenceChannel  →  CH ${if(referenceChannel == 1) 2 else 1}") {
            referenceChannel = if(referenceChannel == 1) 2 else 1
            if(referenceChannel == micChannel) micChannel = if(referenceChannel == 1) 2 else 1
            saveSettings(); renderPage()
        }
        metric("MIC / MEASUREMENT INPUT", "CH $micChannel", "Input mikrofon pengukuran")
        action("MIC CHANNEL • CH $micChannel  →  CH ${if(micChannel == 1) 2 else 1}") {
            micChannel = if(micChannel == 1) 2 else 1
            if(micChannel == referenceChannel) referenceChannel = if(micChannel == 1) 2 else 1
            saveSettings(); renderPage()
        }
        info("Pengaturan global: kanal Mic/Measurement dipakai RTA, IR, dan SPL. Transfer Function memakai kanal Reference + Mic. Perangkat harus menyediakan input stereo agar CH 1/CH 2 dapat dipilih; pada perangkat mono, kanal fisik kedua tidak tersedia.")
        metric("FFT SIZE", settingsFftSize.toString(), "Resolusi frekuensi vs respons waktu")
        action("FFT SIZE • 1024 / 2048 / 4096 / 8192 / 16384 / 32768") { settingsFftSize = when(settingsFftSize){1024->2048;2048->4096;4096->8192;8192->16384;16384->32768;else->1024}; saveSettings(); renderPage() }
        metric("SAMPLE RATE", "$settingsSampleRate Hz", "Preferensi perangkat audio")
        action("SAMPLE RATE • ubah 44100 / 48000 / 96000") { settingsSampleRate = when(settingsSampleRate){44100->48000;48000->96000;else->44100}; saveSettings(); renderPage() }
        metric("AVERAGING", "$settingsAveraging frames", "Jumlah frame untuk stabilisasi tampilan")
        action("AVERAGING • ubah 1 / 4 / 8 / 16 / 32") { settingsAveraging = when(settingsAveraging){1->4;4->8;8->16;16->32;else->1}; saveSettings(); renderPage() }
        metric("WINDOW", settingsWindow, "Windowing mengurangi spectral leakage")
        action("WINDOW • Hann / Hamming / Rectangular") { settingsWindow = when(settingsWindow){"Hann"->"Hamming";"Hamming"->"Rectangular";else->"Hann"}; saveSettings(); renderPage() }
        metric("FREQUENCY SMOOTHING", settingsSmoothing, "Tingkat smoothing tampilan grafik")
        action("SMOOTHING • None / 1/48 / 1/24 / 1/12 / 1/6 / 1/3 / 1 octave") { settingsSmoothing = when(settingsSmoothing){"None"->"1/48 octave";"1/48 octave"->"1/24 octave";"1/24 octave"->"1/12 octave";"1/12 octave"->"1/6 octave";"1/6 octave"->"1/3 octave";"1/3 octave"->"1 octave";else->"None"}; saveSettings(); renderPage() }
        metric("INPUT VOLUME (SOFTWARE GAIN)", String.format(java.util.Locale.US,"%.2f×  (%+.1f dB)",inputGain,20.0*log10(inputGain.toDouble())), "Gain digital sebelum analisis; tidak menaikkan sensitivitas hardware dan dapat menyebabkan clipping.")
        action("INPUT VOLUME −") { inputGain = (inputGain - 0.25f).coerceAtLeast(0.25f); saveSettings(); renderPage() }; action("INPUT VOLUME +") { inputGain = (inputGain + 0.25f).coerceAtMost(2.0f); saveSettings(); renderPage() }
        metric("OUTPUT VOLUME (SIGNAL GENERATOR)", String.format(java.util.Locale.US,"%.2f×  (%+.1f dB)",outputGain,20.0*log10(outputGain.toDouble())), "Gain digital generator; volume perangkat/DAC tetap dapat membatasi level aktual.")
        action("OUTPUT VOLUME −") { outputGain = (outputGain - 0.05f).coerceAtLeast(0.05f); saveSettings(); renderPage() }; action("OUTPUT VOLUME +") { outputGain = (outputGain + 0.05f).coerceAtMost(1.0f); saveSettings(); renderPage() }
        metric("SPL CALIBRATION OFFSET", String.format(java.util.Locale.US,"%.1f dB",splOffsetDb), "Pengaturan offset saat ini")
        action("Configure SPL calibration") { selected="SPL"; buildShell(); renderPage() }
        action("Audio input & output devices") { selected="Audio I/O"; buildShell(); renderPage() }
        info("TF menggunakan FFT/window/averaging yang dipilih saat pengukuran dimulai. Sample rate harus didukung oleh Android dan USB interface; AudioRecord dapat menolak atau melakukan resampling sistem. Smoothing hanya untuk tampilan, bukan memperbaiki coherence rendah.")
    }
    private fun saveSettings() {
        getPreferences(Context.MODE_PRIVATE).edit().putInt("reference_channel",referenceChannel).putInt("mic_channel",micChannel).putInt("rta_channel",rtaChannel).putInt("fft_size",settingsFftSize).putInt("sample_rate",settingsSampleRate).putInt("averaging",settingsAveraging).putString("window",settingsWindow).putString("smoothing",settingsSmoothing).putFloat("input_gain",inputGain).putFloat("output_gain",outputGain).apply()
    }

    private fun savedCaptures(): MutableList<SavedCapture> {
        val out = mutableListOf<SavedCapture>()
        val raw = getPreferences(Context.MODE_PRIVATE).getString("saved_capture_list", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val a = o.getJSONArray("spectrum")
                val data = FloatArray(a.length()) { j -> a.optDouble(j, 0.0).toFloat() }
                out.add(SavedCapture(o.optLong("id"), o.optString("name", "Capture ${i+1}"), o.optString("created", ""), data))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun saveCurrentCapture() {
        val spectrum = when (selected) {
            "Transfer" -> tfMagnitude.copyOf()
            else -> latestSpectrum.copyOf()
        }
        if (spectrum.size < 4 || spectrum.drop(1).all { it <= 1e-9f }) {
            Toast.makeText(this, "Belum ada data terukur yang bisa disimpan. Jalankan pengukuran terlebih dahulu.", Toast.LENGTH_LONG).show(); return
        }
        val captures = savedCaptures()
        val name = "Capture ${captures.size + 1}"
        captures.add(SavedCapture(System.currentTimeMillis(), name, java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()), spectrum))
        persistCaptures(captures.takeLast(10))
        Toast.makeText(this, "$name tersimpan sebagai snapshot ${selected}*. Buka Capture Manager untuk memilihnya.", Toast.LENGTH_LONG).show()
    }

    private fun persistCaptures(captures: List<SavedCapture>) {
        val arr = JSONArray()
        captures.forEach { c ->
            val o = JSONObject().put("id", c.id).put("name", c.name).put("created", c.created)
            val a = JSONArray(); c.spectrum.forEach { a.put(it.toDouble()) }; o.put("spectrum", a); arr.put(o)
        }
        getPreferences(Context.MODE_PRIVATE).edit().putString("saved_capture_list", arr.toString()).apply()
    }

    private fun renderCaptureManager() {
        heading("CAPTURE MANAGER", "Simpan, pilih, dan bandingkan hasil spektrum")
        val nameInput = EditText(this).apply { hint = "Nama capture (mis. Main Speaker)"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted); setBackgroundColor(panel); setPadding(12, 8, 12, 8) }
        captureNameInput = nameInput
        content.addView(nameInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        action("SAVE CURRENT SPECTRUM") {
            val spectrum = latestSpectrum.copyOf()
            if (spectrum.size < 4 || spectrum.drop(1).all { it <= 1e-9f }) {
                Toast.makeText(this, "Belum ada data spektrum. Buka RTA, mulai capture, lalu kembali ke sini.", Toast.LENGTH_LONG).show()
            } else {
                val captures = savedCaptures()
                val custom = nameInput.text.toString().trim()
                val name = if (custom.isBlank()) "Capture ${captures.size + 1}" else custom
                captures.add(SavedCapture(System.currentTimeMillis(), name, java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()), spectrum))
                persistCaptures(captures.takeLast(10)); chosenCaptureIds.clear(); chosenCaptureIds.add(captures.last().id)
                Toast.makeText(this, "Capture tersimpan", Toast.LENGTH_SHORT).show(); renderPage()
            }
        }
        val captures = savedCaptures()
        metric("CAPTURE LIBRARY", "${captures.size} tersimpan", "Pilih satu atau beberapa hasil. Data spektrum tersimpan lokal di perangkat; maksimum 10 capture.")
        if (captures.isEmpty()) info("Belum ada hasil tersimpan. Buka tab RTA, tekan Start live RTA, tunggu grafik bergerak, lalu tekan Save current spectrum to Capture Manager.")
        captures.asReversed().forEach { cap ->
            val cb = CheckBox(this).apply {
                text = "${cap.name}\n${cap.created}"
                textSize = 13f; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(cyan)
                isChecked = chosenCaptureIds.contains(cap.id)
                setPadding(8, 8, 8, 8)
                setOnCheckedChangeListener { _, checked -> if (checked) chosenCaptureIds.add(cap.id) else chosenCaptureIds.remove(cap.id); updateSelectedCapturePreview() }
            }
            content.addView(cb, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 4 })
        }
        heading("SELECTED CAPTURE PREVIEW", "Magnitude dan Phase memakai sumbu frekuensi log yang sama")
        val preview = SpectrumView(this); spectrumView = preview
        content.addView(preview, LinearLayout.LayoutParams(-1, 190).apply { bottomMargin = 4 })
        val phasePreview = TransferView(this, "Phase")
        content.addView(TextView(this).apply { text="LIVE TF PHASE REFERENCE (°)"; setTextColor(Color.WHITE); textSize=11f; setPadding(4,3,4,0) })
        content.addView(phasePreview, LinearLayout.LayoutParams(-1,190).apply { bottomMargin=8 })
        action("REFRESH SELECTED GRAPHS") { updateSelectedCapturePreview(); preview.invalidate(); phasePreview.invalidate() }
        action("CLEAR SELECTION") { chosenCaptureIds.clear(); renderPage() }
        action("DELETE SELECTED CAPTURES") {
            val ids = chosenCaptureIds.toSet(); persistCaptures(savedCaptures().filterNot { ids.contains(it.id) }); chosenCaptureIds.clear(); renderPage()
        }
        heading("TARGET CURVE", "Aktif pada preview magnitude • kurva acuan, bukan prediksi EQ")
        val targetRow = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        listOf("Flat Response", "House Curve", "Speech Tilt").forEach { label ->
            targetRow.addView(Button(this).apply { text=label; textSize=9f; isAllCaps=false; setTextColor(if(targetCurveMode==label) Color.WHITE else cyan); setBackgroundColor(if(targetCurveMode==label) Color.rgb(15,65,78) else panel); setOnClickListener { targetCurveMode=label; targetCurveEnabled=true; renderPage() } }, LinearLayout.LayoutParams(0,42,1f).apply { rightMargin=3 })
        }
        content.addView(targetRow)
        action(if(targetCurveEnabled) "TARGET CURVE: ON" else "TARGET CURVE: OFF") { targetCurveEnabled=!targetCurveEnabled; renderPage() }
        info("Kurva target ditampilkan sebagai referensi visual. Speech Tilt adalah kurva referensi sederhana, bukan kurva ISO 226 terstandar; tidak digunakan untuk mengklaim kalibrasi SPL atau rekomendasi EQ otomatis.")
        heading("AUTO PHASE / ALIGNMENT", "Gunakan data TF live dari input dua kanal")
        action(if(autoPhaseEnabled) "AUTO PHASE: ON" else "RUN AUTO PHASE FROM LIVE TF") {
            val usable=(1 until min(tfPhase.size,tfCoherence.size)).filter { tfCoherence[it] >= 0.5f && tfMagnitude[it].isFinite() && tfMagnitude[it] > -60f }
            if(!recording || usable.size < 12) {
                Toast.makeText(this, "Jalankan Transfer ON dengan referensi dan mikrofon dua kanal; perlu minimal 12 bin TF dengan coherence ≥ 0,5.", Toast.LENGTH_LONG).show()
            } else {
                val unwrapped=mutableListOf<Pair<Int,Double>>()
                var prev=0f; var acc=0.0; var first=true
                usable.forEach { k ->
                    val p=tfPhase[k]
                    if(first) { acc=p.toDouble(); first=false } else { var d=p-prev; while(d>180f)d-=360f; while(d < -180f)d+=360f; acc+=d }
                    prev=p; unwrapped.add(k to acc)
                }
                val mx=unwrapped.map { it.first.toDouble() }.average(); val my=unwrapped.map { it.second }.average()
                val den=unwrapped.sumOf { (k,y) -> (k-mx)*(k-mx) }
                val slope=if(den>0) unwrapped.sumOf { (k,y) -> (k-mx)*(y-my) }/den else 0.0
                if(kotlin.math.abs(slope) < 0.01) {
                    autoPhaseEnabled=true; autoDelayEnabled=true; Toast.makeText(this,"Auto Phase aktif; slope fase terlalu kecil untuk estimasi delay yang andal.",Toast.LENGTH_LONG).show()
                } else {
                    estimatedDelaySamples=(-slope*settingsFftSize/360.0).toFloat().coerceIn(-settingsSampleRate*0.3f,settingsSampleRate*0.3f)
                    autoPhaseEnabled=true; autoDelayEnabled=true; delayConfidence=usable.map { tfCoherence[it] }.average().toFloat()
                    Toast.makeText(this,"Auto Phase aktif • estimasi koreksi ${(estimatedDelaySamples*1000f/settingsSampleRate).let { String.format(java.util.Locale.US, "%.2f ms", it) }}. Verifikasi dengan loopback sebelum alignment kritis.",Toast.LENGTH_LONG).show()
                }
                renderPage()
            }
        }
        info("Auto Phase mengestimasi kemiringan fase dari bin TF dengan coherence ≥ 0,5. Pastikan referensi/mikrofon tersambung benar; validasi dengan loopback sebelum pemakaian alignment profesional.")
        updateSelectedCapturePreview()
    }

    private fun updateSelectedCapturePreview() {
        val selectedCaps = savedCaptures().filter { chosenCaptureIds.contains(it.id) }
        if (selectedCaps.isNotEmpty()) {
            val n = selectedCaps.minOf { it.spectrum.size }
            latestSpectrum = FloatArray(n) { i -> selectedCaps.map { it.spectrum[i] }.average().toFloat() }
        }
        spectrumView?.invalidate()
    }

    private fun startSignal(sweep: Boolean) {
        stopSignal()
        stopCapture()
        val sr = 48000
        val minBytes = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBytes <= 0) { Toast.makeText(this, "Output audio tidak didukung", Toast.LENGTH_LONG).show(); return }
        try {
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(minBytes, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            if (track.state != AudioTrack.STATE_INITIALIZED) { track.release(); Toast.makeText(this, "AudioTrack gagal diinisialisasi", Toast.LENGTH_LONG).show(); return }
            signalTrack = track; signalRunning = true; track.play()
            statusText?.text = if (sweep) "Pink sweep aktif • 20 Hz–20 kHz • 10 s/putaran" else "Pink noise aktif"
            signalThread = thread(name="CAcousticSignal", isDaemon=true) {
                val block = ShortArray(2048)
                val rng = java.util.Random()
                var phase = 0.0
                var index = 0L
                var b0=0.0; var b1=0.0; var b2=0.0; var b3=0.0; var b4=0.0; var b5=0.0; var b6=0.0
                while (signalRunning) {
                    for (i in block.indices) {
                        val sample: Double
                        if (sweep) {
                            val t = (index % (sr * 10L)).toDouble() / sr
                            val duration = 10.0
                            val f0 = 20.0; val f1 = 20000.0
                            val k = duration / kotlin.math.ln(f1 / f0)
                            phase = 2.0 * Math.PI * f0 * k * (kotlin.math.exp(t / k) - 1.0)
                            sample = kotlin.math.sin(phase) * 0.18
                        } else {
                            val white = rng.nextDouble() * 2.0 - 1.0
                            b0 = 0.99886*b0 + white*0.0555179
                            b1 = 0.99332*b1 + white*0.0750759
                            b2 = 0.96900*b2 + white*0.1538520
                            b3 = 0.86650*b3 + white*0.3104856
                            b4 = 0.55000*b4 + white*0.5329522
                            b5 = -0.7616*b5 - white*0.0168980
                            val pink = b0+b1+b2+b3+b4+b5+b6+white*0.5362
                            b6 = white*0.115926
                            sample = (pink * 0.035).coerceIn(-0.25, 0.25)
                        }
                        block[i] = (sample.coerceIn(-0.25, 0.25) * outputGain.toDouble() * 32767.0).toInt().coerceIn(-32768,32767).toShort()
                        index++
                    }
                    var off = 0
                    while (off < block.size && signalRunning) {
                        val wrote = track.write(block, off, block.size-off, AudioTrack.WRITE_BLOCKING)
                        if (wrote <= 0) break else off += wrote
                    }
                }
            }
        } catch (e: Exception) {
            stopSignal()
            Toast.makeText(this, "Gagal memulai generator: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopSignal() {
        signalRunning = false
        try { signalTrack?.pause() } catch (_: Exception) {}
        try { signalTrack?.flush() } catch (_: Exception) {}
        try { signalTrack?.stop() } catch (_: Exception) {}
        try { signalTrack?.release() } catch (_: Exception) {}
        signalTrack = null
        signalThread = null
    }

    private fun requestMicAndStart() { if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),MIC_REQUEST); return }; startCapture() }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) { super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==MIC_REQUEST && grantResults.isNotEmpty() && grantResults[0]==PackageManager.PERMISSION_GRANTED) { if(selected=="Transfer") startTransferCapture() else startCapture() } else Toast.makeText(this,"Izin mikrofon diperlukan untuk RTA live",Toast.LENGTH_LONG).show() }

    private fun startCapture() {
        if(recording) return
        val sampleRate=settingsSampleRate
        val n=settingsFftSize
        val stereoMin=AudioRecord.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_IN_STEREO,AudioFormat.ENCODING_PCM_16BIT)
        val useStereo=stereoMin>0
        if(!useStereo) { Toast.makeText(this,"RTA kanal CH1/CH2 memerlukan input stereo. Perangkat ini tidak melaporkan format stereo.",Toast.LENGTH_LONG).show(); statusText?.text="Input stereo tidak tersedia; RTA kanal terpisah tidak dapat dijamin."; return }
        val channelMask=AudioFormat.CHANNEL_IN_STEREO
        val minBytes=stereoMin
        if(minBytes<=0) { Toast.makeText(this,"Format audio ${sampleRate} Hz tidak didukung; periksa pengaturan sample rate atau perangkat",Toast.LENGTH_LONG).show(); return }
        val bufferBytes=max(minBytes,n*2*2*2)
        try {
            fun createRecorder(source:Int, mask:Int)=AudioRecord(source,sampleRate,mask,AudioFormat.ENCODING_PCM_16BIT,bufferBytes)
            var rec=createRecorder(MediaRecorder.AudioSource.UNPROCESSED,channelMask)
            if(rec.state!=AudioRecord.STATE_INITIALIZED) { rec.release(); rec=createRecorder(MediaRecorder.AudioSource.MIC,channelMask) }
            if(rec.state!=AudioRecord.STATE_INITIALIZED) { rec.release(); Toast.makeText(this,"AudioRecord gagal diinisialisasi",Toast.LENGTH_LONG).show(); return }
            val stereoActive=rec.channelCount>=2
            if(!stereoActive) { rec.release(); Toast.makeText(this,"AudioRecord tidak membuka dua kanal terpisah; RTA CH1/CH2 dibatalkan agar tidak menampilkan hasil yang menyesatkan.",Toast.LENGTH_LONG).show(); statusText?.text="Input stereo terpisah tidak tersedia."; return }
            audioRecord=rec; recording=true; rec.startRecording()
            val activeChannel=rtaChannel
            statusText?.text="Capture aktif • ${sampleRate} Hz • RTA CH $activeChannel / stereo terpisah"
            Toast.makeText(this,"Input aktif • MIC CH $activeChannel",Toast.LENGTH_SHORT).show()
            audioThread=thread(name="CAcousticAudio", isDaemon=true) {
                val shorts=ShortArray(n*2); val floats=FloatArray(n)
                while(recording) {
                    var offset=0
                    while(offset<shorts.size && recording) { val got=rec.read(shorts,offset,shorts.size-offset,AudioRecord.READ_BLOCKING); if(got>0) offset+=got else break }
                    if(!recording || offset<shorts.size) continue
                    var peak=0f
                    for(i in 0 until n) {
                        val sample=shorts[i*2+(activeChannel-1)]
                        floats[i]=(sample/32768f*inputGain).coerceIn(-1f,1f); peak=max(peak,kotlin.math.abs(floats[i]))
                    }
                    latestRms=nativeRms(floats); latestPeak=peak
                    val mags=nativeFftMagnitude(floats); if(mags.isNotEmpty()) latestSpectrum=mags
                    runOnUiThread {
                        spectrumView?.invalidate()
                        if (selected == "SPL") levelText?.text = "Level estimasi ${formatDb(latestRms)} dBFS\nSPL relatif ${String.format(java.util.Locale.US, "%.1f", 20.0 * log10(max(1e-9f, latestRms).toDouble()) + splOffsetDb)} dB SPL"
                        else levelText?.text = "RMS ${formatDb(latestRms)} dBFS   •   Peak ${formatDb(latestPeak)} dBFS"
                        statusText?.text = "Capture aktif • ${sampleRate} Hz • MIC CH $activeChannel"
                    }
                }
            }
        } catch(e:Exception) { recording=false; Toast.makeText(this,"Gagal memulai audio: ${e.message}",Toast.LENGTH_LONG).show() }
    }
    private fun requestMicAndStartTransfer() {
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),MIC_REQUEST); return }
        startTransferCapture()
    }
    private fun startTransferCapture() {
        if(recording) return
        val sr=settingsSampleRate; val n=settingsFftSize; val mask=AudioFormat.CHANNEL_IN_STEREO
        val minBytes=AudioRecord.getMinBufferSize(sr,mask,AudioFormat.ENCODING_PCM_16BIT)
        if(minBytes<=0) { transferStatus?.text="Stereo 48 kHz tidak didukung input ini. Coba interface USB 2-in."; return }
        val bytes=max(minBytes,n*2*2*2)
        try {
            val rec=AudioRecord(MediaRecorder.AudioSource.UNPROCESSED,sr,mask,AudioFormat.ENCODING_PCM_16BIT,bytes)
            if(rec.state!=AudioRecord.STATE_INITIALIZED) { rec.release(); transferStatus?.text="AudioRecord stereo gagal. Perangkat mungkin hanya menyediakan input mono."; return }
            audioRecord=rec; recording=true; rec.startRecording(); transferStatus?.text="Capture stereo aktif • CH$referenceChannel reference / CH$micChannel mic"
            audioThread=thread(name="CAcousticTransfer",isDaemon=true) {
                val interleaved=ShortArray(n*2); val r=FloatArray(n); val m=FloatArray(n)
                val delayWindowSize=(sr*0.60f).toInt().coerceAtLeast(n)
                val histR=FloatArray(delayWindowSize); val histM=FloatArray(delayWindowSize)
                var histWrite=0; var histCount=0
                tfMagnitude=FloatArray(n/2+1); tfPhase=FloatArray(n/2+1); tfCoherence=FloatArray(n/2+1)
                val avgR=FloatArray(n/2+1); val avgM=FloatArray(n/2+1); val avgCr=FloatArray(n/2+1); val avgCi=FloatArray(n/2+1); var frames=0; var delayInitialized=false
                while(recording) {
                    var off=0; while(off<interleaved.size && recording) { val got=rec.read(interleaved,off,interleaved.size-off,AudioRecord.READ_BLOCKING); if(got>0) off+=got else break }
                    if(!recording || off<interleaved.size) continue
                    for(i in 0 until n){ val ch1=interleaved[i*2]/32768f; val ch2=interleaved[i*2+1]/32768f; r[i]=if(referenceChannel==1) ch1 else ch2; m[i]=if(micChannel==1) ch1 else ch2 }
                    val windowId=when(settingsWindow){"Hamming"->1;"Rectangular"->2;else->0}
                    val raw=nativeTransferFrame(r,m,windowId); if(raw.size<(n/2+1)*4) continue
                    frames++
                    val alpha=1f/settingsAveraging.coerceAtLeast(1)
                    for(i in 0 until n) { histR[histWrite]=r[i]; histM[histWrite]=m[i]; histWrite=(histWrite+1)%delayWindowSize; histCount=min(delayWindowSize,histCount+1) }
                    if(autoDelayEnabled && frames % 8 == 0 && histCount >= n) {
                        val hr=FloatArray(histCount); val hm=FloatArray(histCount)
                        val start=(histWrite-histCount+delayWindowSize)%delayWindowSize
                        for(i in 0 until histCount) { val ix=(start+i)%delayWindowSize; hr[i]=histR[ix]; hm[i]=histM[ix] }
                        val estimate=nativeEstimateLagNormalized(hr,hm,min(histCount/2,(sr*0.30f).toInt()))
                        val lag=estimate.getOrElse(0){0f}; val confidence=estimate.getOrElse(1){0f}
                        if(confidence >= 0.20f) {
                            if(!delayInitialized || !delayTrackerEnabled) { estimatedDelaySamples=lag; delayInitialized=true }
                            else estimatedDelaySamples=estimatedDelaySamples*0.85f+lag*0.15f
                            delayConfidence=confidence
                        } else delayConfidence=confidence
                    }
                    for(k in avgR.indices){ val j=k*4; avgR[k]=avgR[k]*(1-alpha)+raw[j]*alpha; avgM[k]=avgM[k]*(1-alpha)+raw[j+1]*alpha; avgCr[k]=avgCr[k]*(1-alpha)+raw[j+2]*alpha; avgCi[k]=avgCi[k]*(1-alpha)+raw[j+3]*alpha }
                    val rawMagnitude=FloatArray(avgR.size) { k -> (10.0*log10(max(1e-12f,avgM[k])/max(1e-12f,avgR[k]))).toFloat() }
                    val smoothRadius=when(settingsSmoothing){"1/48 octave"->1;"1/24 octave"->2;"1/12 octave"->3;"1/6 octave"->5;"1/3 octave"->9;"1 octave"->18;else->0}
                    for(k in avgR.indices){
                        if(smoothRadius==0) tfMagnitude[k]=rawMagnitude[k] else { var sum=0f; var cnt=0; for(j in max(0,k-smoothRadius)..min(rawMagnitude.lastIndex,k+smoothRadius)){sum+=rawMagnitude[j];cnt++}; tfMagnitude[k]=sum/cnt }
                        var phase=Math.toDegrees(kotlin.math.atan2(avgCi[k].toDouble(),avgCr[k].toDouble())).toFloat()
                        if(autoPhaseEnabled && autoDelayEnabled) phase += 360f*k*estimatedDelaySamples/n
                        while(phase>180f) phase-=360f; while(phase < -180f) phase+=360f
                        tfPhase[k]=phase; tfCoherence[k]=((avgCr[k]*avgCr[k]+avgCi[k]*avgCi[k])/max(1e-20f,avgR[k]*avgM[k])).coerceIn(0f,1f) }
                    runOnUiThread { transferView?.invalidate(); transferPhaseView?.invalidate(); transferStatus?.text="TF live • $sr Hz • FFT $n • avg $settingsAveraging • delay ${String.format(java.util.Locale.US, "%.2f",estimatedDelaySamples*1000f/sr)} ms • confidence ${String.format(java.util.Locale.US, "%.2f",delayConfidence)} • AutoPhase ${if(autoPhaseEnabled) "ON" else "OFF"}" }
                }
            }
        } catch(e:Exception) { recording=false; transferStatus?.text="Gagal memulai stereo capture: ${e.message}" }
    }

    private fun stopCapture() { recording=false; try { audioRecord?.stop() } catch(_:Exception){}; try { audioRecord?.release() } catch(_:Exception){}; audioRecord=null; audioThread=null }
    private fun formatDb(v:Float):String = if(v<=0f) "−∞" else String.format(java.util.Locale.US,"%.1f",20.0*log10(v.toDouble()))

    private fun heading(t:String,d:String) { content.addView(TextView(this).apply { text=t; textSize=17f; setTextColor(Color.WHITE); typeface=android.graphics.Typeface.DEFAULT_BOLD }); content.addView(TextView(this).apply { text=d; textSize=11f; setTextColor(muted); setPadding(0,3,0,12) }) }
    private fun metric(l:String,v:String,d:String) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(12,12,12,12) }; box.addView(TextView(this).apply { text=l; textSize=10f; setTextColor(muted) }); box.addView(TextView(this).apply { text=v; textSize=20f; setTextColor(cyan); typeface=android.graphics.Typeface.DEFAULT_BOLD; setPadding(0,4,0,2) }); box.addView(TextView(this).apply { text=d; textSize=11f; setTextColor(Color.WHITE) }); content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 }) }
    private fun graphBox(title:String, heightDp:Int=320) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(8,8,8,8) }; box.addView(TextView(this).apply { text=title; textSize=12f; setTextColor(Color.WHITE); typeface=android.graphics.Typeface.DEFAULT_BOLD }); val graph=SpectrumView(this); spectrumView=graph; box.addView(graph,LinearLayout.LayoutParams(-1,heightDp).apply { topMargin=5 }); content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=6 }) }
    private fun compactActionRow(toggleLabel:String, captureLabel:String, toggle:()->Unit, capture:()->Unit) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,2,0,4) }
        fun smallButton(label:String, handler:()->Unit)=Button(this).apply { text=label; textSize=11f; isAllCaps=false; minHeight=36; minimumHeight=36; minWidth=0; setPadding(6,0,6,0); setTextColor(cyan); setOnClickListener { handler() } }
        row.addView(smallButton(toggleLabel,toggle),LinearLayout.LayoutParams(0,38,1f).apply { rightMargin=6 })
        row.addView(smallButton(captureLabel,capture),LinearLayout.LayoutParams(0,38,1f))
        content.addView(row,LinearLayout.LayoutParams(-1,42))
    }
    private fun info(s:String) { content.addView(TextView(this).apply { text=s; textSize=12f; setTextColor(muted); setPadding(6,8,6,12) }) }
    private fun action(label:String,fn:()->Unit) { content.addView(Button(this).apply { text=label; isAllCaps=false; setTextColor(cyan); setOnClickListener { fn() } },LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 }) }
    private fun listAudioDevices() { val am=getSystemService(Context.AUDIO_SERVICE) as AudioManager; val devices=if(Build.VERSION.SDK_INT>=23) am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList() else emptyList(); val lines=devices.map { d -> "${d.productName} • ${typeName(d.type)} • ${d.channelCounts.joinToString()} ch" }; info(if(lines.isEmpty()) "Tidak ada input device eksternal yang terdeteksi. Mikrofon bawaan mungkin tetap tersedia melalui AudioRecord." else "Input terdeteksi:\n"+lines.joinToString("\n")) }
    private fun typeName(t:Int)=when(t){AudioDeviceInfo.TYPE_BUILTIN_MIC->"Built-in mic";AudioDeviceInfo.TYPE_USB_DEVICE->"USB device";AudioDeviceInfo.TYPE_USB_HEADSET->"USB headset";AudioDeviceInfo.TYPE_WIRED_HEADSET->"Wired headset";AudioDeviceInfo.TYPE_BLUETOOTH_SCO->"Bluetooth SCO";else->"Audio type $t"}

    private inner class TimeResponseView(ctx:Context):View(ctx) {
        var displayMode:String = "Lin"
        private var plotZoom = 1f
        private val zoomDetector = android.view.ScaleGestureDetector(ctx, object: android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: android.view.ScaleGestureDetector): Boolean {
                plotZoom = (plotZoom * detector.scaleFactor).coerceIn(1f, 5f)
                invalidate()
                return true
            }
        })
        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            zoomDetector.onTouchEvent(event)
            tapDetector.onTouchEvent(event)
            return true
        }
        private val tapDetector = android.view.GestureDetector(ctx, object: android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                plotZoom = 1f
                invalidate()
                return true
            }
        })
        private val grid=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(35,57,73); strokeWidth=1f }
        private val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cyan; strokeWidth=2.2f; style=Paint.Style.STROKE }
        private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=muted; textSize=10f }
        override fun onDraw(c:Canvas) {
            super.onDraw(c); c.drawColor(Color.rgb(7,19,31))
            c.save()
            c.scale(plotZoom, plotZoom, width / 2f, height / 2f)
            val l=38f; val r=width-8f; val t=8f; val b=height-19f
            for(i in 0..4) { val y=t+(b-t)*i/4f; c.drawLine(l,y,r,y,grid) }
            for(i in 0..4) { val x=l+(r-l)*i/4f; c.drawLine(x,t,x,b,grid) }
            val labels=when(displayMode) { "Log" -> listOf("-10 ms","-1 ms","0","1 ms","10 ms"); "ETC" -> listOf("0","-10 dB","-20 dB","-30 dB","-40 dB"); else -> listOf("-20 ms","-10 ms","0","10 ms","20 ms") }
            labels.forEachIndexed { i,label -> c.drawText(label,(l+(r-l)*i/4f)-15,b+13,text) }
            if(displayMode=="ETC") c.drawText("ETC / TIME DATA NOT CAPTURED",l+6f,(t+b)/2f,text)
            else c.drawText("Impulse/time data requires synchronized IR capture",l+6f,(t+b)/2f,text)
            c.drawLine(l,(t+b)/2f,r,(t+b)/2f,grid)
            c.restore()
        }
    }

    private inner class TransferView(ctx:Context, private val plotMode:String = tfDisplayMode):View(ctx) {
        private var plotZoom = 1f
        private val zoomDetector = android.view.ScaleGestureDetector(ctx, object: android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: android.view.ScaleGestureDetector): Boolean {
                plotZoom = (plotZoom * detector.scaleFactor).coerceIn(1f, 5f)
                invalidate()
                return true
            }
        })
        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            zoomDetector.onTouchEvent(event)
            tapDetector.onTouchEvent(event)
            return true
        }
        private val tapDetector = android.view.GestureDetector(ctx, object: android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                plotZoom = 1f
                invalidate()
                return true
            }
        })
        private val grid=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(35,57,73); strokeWidth=1f }
        private val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cyan; strokeWidth=2.2f; style=Paint.Style.STROKE }
        private val coherenceLine=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(255,70,80); strokeWidth=2.2f; style=Paint.Style.STROKE }
        private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=muted; textSize=10f }
        override fun onDraw(c:Canvas) {
            super.onDraw(c); c.drawColor(Color.rgb(7,19,31))
            c.save()
            c.scale(plotZoom, plotZoom, width / 2f, height / 2f)
            val l=36f; val r=width-8f; val t=8f; val b=height-19f
            val mode=plotMode
            val minY=if(mode=="Phase") -180f else -18f
            val maxY=if(mode=="Phase") 180f else 18f
            for(i in 0..4){
                val v=maxY-(maxY-minY)*i/4f; val y=t+(b-t)*i/4f
                c.drawLine(l,y,r,y,grid)
                c.drawText(String.format(java.util.Locale.US,"%.0f",v),2f,y-2,text)
            }
            val maxFreq=min(settingsSampleRate/2f,20000f).coerceAtLeast(200f)
            val freqLabels=listOf(20f,100f,1000f,10000f,maxFreq).distinct().sorted()
            freqLabels.forEach { f -> val x=frequencyX(f,maxFreq,l,r); c.drawLine(x,t,x,b,grid); c.drawText(if(f>=1000f) String.format(java.util.Locale.US,"%.0fk",f/1000f) else "${f.toInt()}",x-10,b+13,text) }
            if(mode=="Frequency+Coherence") {
                drawSeries(c,tfMagnitude,minY,maxY,l,r,t,b,line,maxFreq)
                val path=Path(); val a=tfCoherence; var started=false
                for(i in 1 until a.size){ val f=i.toFloat()*settingsSampleRate/(2f*(a.size-1)); if(f<20f || f>maxFreq) continue; val v=a[i].coerceIn(0f,1f); val y=b-v*(b-t); val x=frequencyX(f,maxFreq,l,r); if(!started){path.moveTo(x,y);started=true}else path.lineTo(x,y) }
                if(started)c.drawPath(path,coherenceLine)
                c.drawText("1.0",r-25,t+9,text); c.drawText("0.0",r-25,b-2,text)
            } else {
                val a=if(mode=="Phase") tfPhase else tfMagnitude
                drawSeries(c,a,minY,maxY,l,r,t,b,line,maxFreq)
            }
            c.restore()
        }
        private fun frequencyX(freq:Float,maxFreq:Float,l:Float,r:Float):Float { val lo=20f; val f=freq.coerceIn(lo,maxFreq); return l+(kotlin.math.ln(f/lo)/kotlin.math.ln(maxFreq/lo))*(r-l) }
        private fun drawSeries(c:Canvas,a:FloatArray,minY:Float,maxY:Float,l:Float,r:Float,t:Float,b:Float,paint:Paint,maxFreq:Float) {
            if(a.size<4)return
            val path=Path(); var started=false
            for(i in 1 until a.size){ val f=i.toFloat()*settingsSampleRate/(2f*(a.size-1)); if(f<20f || f>maxFreq) continue; val v=a[i].coerceIn(minY,maxY); val y=t+((maxY-v)/(maxY-minY))*(b-t); val x=frequencyX(f,maxFreq,l,r); if(!started){path.moveTo(x,y);started=true}else path.lineTo(x,y) }
            if(started)c.drawPath(path,paint)
        }
    }

    private inner class SpectrumView(ctx:Context):View(ctx) {
        private var plotZoom = 1f
        private val zoomDetector = android.view.ScaleGestureDetector(ctx, object: android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: android.view.ScaleGestureDetector): Boolean { plotZoom=(plotZoom*detector.scaleFactor).coerceIn(1f,5f); invalidate(); return true }
        })
        private val tapDetector = android.view.GestureDetector(ctx, object: android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                plotZoom = 1f
                invalidate()
                return true
            }
        })
        private val grid=Paint( Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(35,57,73); strokeWidth=1f }
        private val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cyan; strokeWidth=3f; style=Paint.Style.STROKE }
        private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=muted; textSize=10f }
        override fun onTouchEvent(event:android.view.MotionEvent):Boolean { zoomDetector.onTouchEvent(event); tapDetector.onTouchEvent(event); return true }
        override fun onDraw(c:Canvas) { super.onDraw(c); c.drawColor(Color.rgb(7,19,31)); c.save(); c.scale(plotZoom,plotZoom,width/2f,height/2f); val left=34f; val right=width-8f; val top=12f; val bottom=height-22f
            // Fixed display range: +60 dB at the top, -60 dB at the bottom.
            for(i in 0..6) { val db=60-i*20; val y=top+(bottom-top)*i/6f; c.drawLine(left,y,right,y,grid); c.drawText("${db} dB",2f,y-2,text) }
            val maxFreq=min(settingsSampleRate/2f,20000f).coerceAtLeast(200f)
            listOf(20f,100f,1000f,10000f,maxFreq).distinct().sorted().forEach { f -> val x=left+(kotlin.math.ln(f/20f)/kotlin.math.ln(maxFreq/20f))*(right-left); c.drawLine(x,top,x,bottom,grid); c.drawText(if(f>=1000f) String.format(java.util.Locale.US,"%.0fk",f/1000f) else "${f.toInt()}",x-10,bottom+15,text) }
            val mags=latestSpectrum; if(mags.size<4) { c.restore(); return }
            val path=Path(); var started=false
            for(i in 1 until mags.size){ val f=i.toFloat()*settingsSampleRate/(2f*(mags.size-1)); if(f<20f || f>maxFreq)continue; val db=(20*log10(max(1e-6f,mags[i]))).coerceIn(-60f,60f); val y=top+((60f-db)/120f)*(bottom-top); val x=left+(kotlin.math.ln(f/20f)/kotlin.math.ln(maxFreq/20f))*(right-left); if(!started){path.moveTo(x,y);started=true}else path.lineTo(x,y) }
            if(started)c.drawPath(path,line)
            if(targetCurveEnabled){ val target=Path(); var ts=false; for(i in 1 until mags.size){ val f=i.toFloat()*settingsSampleRate/(2f*(mags.size-1)); if(f<20f || f>maxFreq)continue; val db=when(targetCurveMode){"House Curve" -> if(f<100f) 4f else if(f<1000f) 4f-(kotlin.math.ln(f/100f)/kotlin.math.ln(10f))*4f else if(f<10000f) 0f-2f*(kotlin.math.ln(f/1000f)/kotlin.math.ln(10f)) else -2f; "Speech Tilt" -> if(f<100f) -3f else if(f<1000f) 0f else if(f<5000f) 1f else -1f; else -> 0f }; val y=top+((0f-db+60f)/120f)*(bottom-top); val x=left+(kotlin.math.ln(f/20f)/kotlin.math.ln(maxFreq/20f))*(right-left); if(!ts){target.moveTo(x,y);ts=true}else target.lineTo(x,y) }; if(ts){val targetPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.YELLOW;strokeWidth=2f;style=Paint.Style.STROKE;pathEffect=android.graphics.DashPathEffect(floatArrayOf(8f,5f),0f)};c.drawPath(target,targetPaint)} }
            c.restore()
        }
    }
}
