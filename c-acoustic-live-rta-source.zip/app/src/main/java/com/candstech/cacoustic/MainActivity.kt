package com.candstech.cacoustic

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.AudioFormat
import android.os.Build
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.provider.Settings
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private external fun nativeDspStatus(): String
    private external fun nativeRms(samples: FloatArray): Float
    private external fun nativeEstimateLag(reference: FloatArray, measured: FloatArray, maxLag: Int): Int
    private external fun nativeFftMagnitude(samples: FloatArray): FloatArray
    companion object { private const val MIC_REQUEST = 41; init { System.loadLibrary("cacoustic_dsp") } }

    private val bg = Color.rgb(5, 14, 25); private val panel = Color.rgb(12, 27, 42)
    private val cyan = Color.rgb(53, 215, 239); private val muted = Color.rgb(151, 177, 196)
    private var selected = "RTA"; private lateinit var content: LinearLayout
    @Volatile private var recording = false
    private var audioRecord: AudioRecord? = null
    private var audioThread: Thread? = null
    private var spectrumView: SpectrumView? = null
    private var statusText: TextView? = null
    private var levelText: TextView? = null
    @Volatile private var latestSpectrum = FloatArray(2049)
    @Volatile private var latestRms = 0f
    @Volatile private var latestPeak = 0f

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=bg; window.navigationBarColor=bg; buildShell(); renderPage() }
    override fun onDestroy() { stopCapture(); super.onDestroy() }
    override fun onPause() { super.onPause(); stopCapture() }

    private fun buildShell() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(12,10,12,8) }
        root.addView(TextView(this).apply { text="C ACOUSTIC"; textSize=27f; typeface=android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD); setTextColor(cyan) })
        root.addView(TextView(this).apply { text="CANDSTECH  •  AUDIO ANALYSIS & SYSTEM TUNING"; textSize=10f; setTextColor(muted); setPadding(0,2,0,12) })
        val hs=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false }; val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("RTA","Transfer","Impulse","SPL","Audio I/O","Auto Phase").forEach { tab ->
            tabs.addView(Button(this).apply { text=tab; textSize=10f; isAllCaps=false; setTextColor(if(tab==selected) cyan else Color.WHITE); setBackgroundColor(if(tab==selected) Color.rgb(20,55,69) else panel); setOnClickListener { stopCapture(); selected=tab; buildShell(); renderPage() } },LinearLayout.LayoutParams(-2,-2).apply { rightMargin=5 })
        }
        hs.addView(tabs); root.addView(hs)
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,14,0,0) }
        root.addView(ScrollView(this).apply { addView(content) },LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun renderPage() {
        content.removeAllViews(); spectrumView=null; statusText=null; levelText=null
        when(selected) {
            "RTA" -> {
                heading("REAL-TIME ANALYZER","Live microphone FFT • 48 kHz preferred")
                metric("FFT SIZE","4096","Frequency resolution depends on sample rate")
                graphBox("RTA SPECTRUM")
                levelText=TextView(this).apply { text="Level: —"; textSize=14f; setTextColor(cyan); setPadding(4,8,4,8) }; content.addView(levelText)
                statusText=TextView(this).apply { text="Mikrofon belum aktif"; textSize=11f; setTextColor(muted); setPadding(4,4,4,8) }; content.addView(statusText)
                action("Start live RTA") { requestMicAndStart() }; action("Stop capture") { stopCapture(); statusText?.text="Capture dihentikan" }
            }
            "Transfer" -> { heading("TRANSFER FUNCTION","Magnitude • Phase • Coherence"); metric("INPUT","2-channel required","Reference and measurement must be synchronous"); graphBox("MAGNITUDE / PHASE"); info("Belum aktif: memerlukan dua kanal input tersinkronisasi. Tidak ditampilkan sebagai hasil ukur palsu.") }
            "Impulse" -> { heading("IMPULSE RESPONSE","Arrival time & delay analysis"); graphBox("IMPULSE RESPONSE"); info("Live capture satu kanal tersedia melalui RTA. IR windowing, timing reference, dan peak detection masih perlu validasi sebelum digunakan untuk pengukuran profesional.") }
            "SPL" -> { heading("SPL METER","Relative level • calibration required"); metric("LEVEL", if(recording) "Live" else "Standby","dB SPL tidak ditampilkan tanpa kalibrasi mikrofon"); info("Gunakan tombol RTA untuk capture. dBFS/level relatif bukan dB SPL; masukkan sensitivitas mikrofon dan kalibrasi akustik sebelum pengukuran SPL.") }
            "Audio I/O" -> { heading("AUDIO DEVICE & ROUTING","Android input devices • USB/OTG where supported"); action("Refresh audio devices") { listAudioDevices() }; action("Open Android sound settings") { startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }; info(nativeDspStatus()); listAudioDevices() }
            else -> { heading("AUTO PHASE","Main + sub alignment assistant"); metric("MODE","Analysis pending","Dual-channel capture needed for reliable alignment"); graphBox("MAIN + SUB ALIGNMENT"); info("Auto Phase belum memberi rekomendasi delay/polarity tanpa capture reference dan sub yang sinkron. Jangan gunakan estimasi sintetis untuk tuning sistem live.") }
        }
        content.addView(TextView(this).apply { text="C ACOUSTIC • LIVE RTA PROTOTYPE • DSP VALIDATION REQUIRED"; textSize=9f; setTextColor(muted); setPadding(0,18,0,8) })
    }
    private fun requestMicAndStart() { if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),MIC_REQUEST); return }; startCapture() }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) { super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==MIC_REQUEST && grantResults.isNotEmpty() && grantResults[0]==PackageManager.PERMISSION_GRANTED) startCapture() else Toast.makeText(this,"Izin mikrofon diperlukan untuk RTA live",Toast.LENGTH_LONG).show() }

    private fun startCapture() {
        if(recording) return
        val sampleRate=48000; val minBytes=AudioRecord.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        if(minBytes<=0) { Toast.makeText(this,"Format audio 48 kHz tidak didukung; coba perangkat lain",Toast.LENGTH_LONG).show(); return }
        val bufferBytes=max(minBytes,4096*2*2)
        try {
            val rec=AudioRecord(MediaRecorder.AudioSource.UNPROCESSED,sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,bufferBytes).let { if(it.state!=AudioRecord.STATE_INITIALIZED) { it.release(); AudioRecord(MediaRecorder.AudioSource.MIC,sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,bufferBytes) } else it }
            if(rec.state!=AudioRecord.STATE_INITIALIZED) { rec.release(); Toast.makeText(this,"AudioRecord gagal diinisialisasi",Toast.LENGTH_LONG).show(); return }
            audioRecord=rec; recording=true; rec.startRecording(); statusText?.text="Capture aktif • 48 kHz • mikrofon Android"; Toast.makeText(this,"RTA live aktif",Toast.LENGTH_SHORT).show()
            audioThread=thread(name="CAcousticAudio", isDaemon=true) {
                val n=4096; val shorts=ShortArray(n); val floats=FloatArray(n)
                while(recording) {
                    var offset=0
                    while(offset<n && recording) { val got=rec.read(shorts,offset,n-offset,AudioRecord.READ_BLOCKING); if(got>0) offset+=got else break }
                    if(!recording || offset<n) continue
                    var peak=0f
                    for(i in 0 until n) { floats[i]=shorts[i]/32768f; peak=max(peak,kotlin.math.abs(floats[i])) }
                    latestRms=nativeRms(floats); latestPeak=peak
                    val mags=nativeFftMagnitude(floats); if(mags.isNotEmpty()) latestSpectrum=mags
                    runOnUiThread { spectrumView?.invalidate(); levelText?.text="RMS ${formatDb(latestRms)} dBFS   •   Peak ${formatDb(latestPeak)} dBFS" }
                }
            }
        } catch(e:Exception) { recording=false; Toast.makeText(this,"Gagal memulai audio: ${e.message}",Toast.LENGTH_LONG).show() }
    }
    private fun stopCapture() { recording=false; try { audioRecord?.stop() } catch(_:Exception){}; try { audioRecord?.release() } catch(_:Exception){}; audioRecord=null; audioThread=null }
    private fun formatDb(v:Float):String = if(v<=0f) "−∞" else String.format(java.util.Locale.US,"%.1f",20.0*log10(v.toDouble()))

    private fun heading(t:String,d:String) { content.addView(TextView(this).apply { text=t; textSize=17f; setTextColor(Color.WHITE); typeface=android.graphics.Typeface.DEFAULT_BOLD }); content.addView(TextView(this).apply { text=d; textSize=11f; setTextColor(muted); setPadding(0,3,0,12) }) }
    private fun metric(l:String,v:String,d:String) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(12,12,12,12) }; box.addView(TextView(this).apply { text=l; textSize=10f; setTextColor(muted) }); box.addView(TextView(this).apply { text=v; textSize=20f; setTextColor(cyan); typeface=android.graphics.Typeface.DEFAULT_BOLD; setPadding(0,4,0,2) }); box.addView(TextView(this).apply { text=d; textSize=11f; setTextColor(Color.WHITE) }); content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 }) }
    private fun graphBox(title:String) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(10,10,10,12) }; box.addView(TextView(this).apply { text=title; textSize=12f; setTextColor(Color.WHITE); typeface=android.graphics.Typeface.DEFAULT_BOLD }); val graph=SpectrumView(this); spectrumView=graph; box.addView(graph,LinearLayout.LayoutParams(-1,220).apply { topMargin=8 }); content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 }) }
    private fun info(s:String) { content.addView(TextView(this).apply { text=s; textSize=12f; setTextColor(muted); setPadding(6,8,6,12) }) }
    private fun action(label:String,fn:()->Unit) { content.addView(Button(this).apply { text=label; isAllCaps=false; setTextColor(cyan); setOnClickListener { fn() } },LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 }) }
    private fun listAudioDevices() { val am=getSystemService(Context.AUDIO_SERVICE) as AudioManager; val devices=if(Build.VERSION.SDK_INT>=23) am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList() else emptyList(); val lines=devices.map { d -> "${d.productName} • ${typeName(d.type)} • ${d.channelCounts.joinToString()} ch" }; info(if(lines.isEmpty()) "Tidak ada input device eksternal yang terdeteksi. Mikrofon bawaan mungkin tetap tersedia melalui AudioRecord." else "Input terdeteksi:\n"+lines.joinToString("\n")) }
    private fun typeName(t:Int)=when(t){AudioDeviceInfo.TYPE_BUILTIN_MIC->"Built-in mic";AudioDeviceInfo.TYPE_USB_DEVICE->"USB device";AudioDeviceInfo.TYPE_USB_HEADSET->"USB headset";AudioDeviceInfo.TYPE_WIRED_HEADSET->"Wired headset";AudioDeviceInfo.TYPE_BLUETOOTH_SCO->"Bluetooth SCO";else->"Audio type $t"}

    private inner class SpectrumView(ctx:Context):View(ctx) {
        private val grid=Paint( Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(35,57,73); strokeWidth=1f }
        private val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cyan; strokeWidth=3f; style=Paint.Style.STROKE }
        private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=muted; textSize=10f }
        override fun onDraw(c:Canvas) { super.onDraw(c); c.drawColor(Color.rgb(7,19,31)); val left=34f; val right=width-8f; val top=12f; val bottom=height-22f
            for(i in 0..5) { val y=top+(bottom-top)*i/5f; c.drawLine(left,y,right,y,grid); c.drawText("${-i*12} dB",2f,y-2,text) }
            val freqs=listOf("20","100","1k","10k","20k"); for(i in 0..4) { val x=left+(right-left)*i/4f; c.drawLine(x,top,x,bottom,grid); c.drawText(freqs[i],x-8,bottom+15,text) }
            val mags=latestSpectrum; if(mags.size<4) return
            val path=Path(); val count= min(500,mags.size-1); for(i in 1..count) { val norm=i.toFloat()/count; val db=(20*log10(max(1e-6f,mags[i]))).coerceIn(-72f,0f); val y=bottom-(db+72f)/72f*(bottom-top); val x=left+norm*(right-left); if(i==1) path.moveTo(x,y) else path.lineTo(x,y) }; c.drawPath(path,line)
        }
    }
}
