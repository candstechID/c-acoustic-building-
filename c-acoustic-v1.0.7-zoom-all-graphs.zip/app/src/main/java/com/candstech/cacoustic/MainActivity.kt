package com.candstech.cacoustic

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.media.AudioFormat
import android.os.Build
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.provider.Settings
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private external fun nativeDspStatus(): String
    private external fun nativeRms(samples: FloatArray): Float
    private external fun nativeEstimateLag(reference: FloatArray, measured: FloatArray, maxLag: Int): Int
    private external fun nativeFftMagnitude(samples: FloatArray): FloatArray
    private external fun nativeTransferFrame(reference: FloatArray, measured: FloatArray): FloatArray
    companion object { private const val MIC_REQUEST = 41; init { System.loadLibrary("cacoustic_dsp") } }

    private val bg = Color.rgb(5, 14, 25); private val panel = Color.rgb(12, 27, 42)
    private val cyan = Color.rgb(53, 215, 239); private val muted = Color.rgb(151, 177, 196)
    private var selected = "RTA"; private lateinit var content: LinearLayout
    private data class SavedCapture(val id: Long, val name: String, val created: String, val spectrum: FloatArray)
    private val chosenCaptureIds = linkedSetOf<Long>()
    private var captureNameInput: EditText? = null
    private var splOffsetDb = 120f
    private var inputGain = 1.0f
    private var outputGain = 0.25f
    private var settingsFftSize = 4096
    private var settingsSampleRate = 48000
    private var settingsAveraging = 8
    private var settingsSmoothing = "1/3 octave"
    private var settingsWindow = "Hann"
    @Volatile private var recording = false
    private var audioRecord: AudioRecord? = null
    private var audioThread: Thread? = null
    private var spectrumView: SpectrumView? = null
    private var statusText: TextView? = null
    private var levelText: TextView? = null
    private var transferView: TransferView? = null
    private var transferStatus: TextView? = null
    @Volatile private var signalRunning = false
    private var signalMode = "Pink Noise"
    private var signalTrack: AudioTrack? = null
    private var signalThread: Thread? = null
    @Volatile private var tfMagnitude = FloatArray(2049)
    @Volatile private var tfPhase = FloatArray(2049)
    @Volatile private var tfCoherence = FloatArray(2049)
    private var tfDisplayMode = "Magnitude"
    @Volatile private var latestSpectrum = FloatArray(2049)
    @Volatile private var latestRms = 0f
    @Volatile private var latestPeak = 0f

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); splOffsetDb = getPreferences(Context.MODE_PRIVATE).getFloat("spl_offset_db", 120f); inputGain=getPreferences(Context.MODE_PRIVATE).getFloat("input_gain",1.0f); outputGain=getPreferences(Context.MODE_PRIVATE).getFloat("output_gain",0.25f); settingsFftSize=getPreferences(Context.MODE_PRIVATE).getInt("fft_size",4096); settingsSampleRate=getPreferences(Context.MODE_PRIVATE).getInt("sample_rate",48000); settingsAveraging=getPreferences(Context.MODE_PRIVATE).getInt("averaging",8); settingsSmoothing=getPreferences(Context.MODE_PRIVATE).getString("smoothing","1/3 octave") ?: "1/3 octave"; settingsWindow=getPreferences(Context.MODE_PRIVATE).getString("window","Hann") ?: "Hann"; window.statusBarColor=bg; window.navigationBarColor=bg; buildShell(); renderPage() }
    override fun onDestroy() { stopCapture(); stopSignal(); super.onDestroy() }
    override fun onPause() { super.onPause(); stopCapture(); stopSignal() }

    private fun buildShell() {
        val root=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; setBackgroundColor(bg); setPadding(8,8,8,8) }
        val sidebar=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(8,22,36)); setPadding(7,8,7,8) }
        sidebar.addView(TextView(this).apply { text="C ACOUSTIC"; textSize=16f; typeface=android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD); setTextColor(cyan); setPadding(3,0,3,0) })
        sidebar.addView(TextView(this).apply { text="AUDIO ANALYSIS • SYSTEM TUNING"; textSize=7f; setTextColor(muted); setPadding(3,0,3,10) })
        listOf("RTA","Transfer","Impulse","SPL","Signal","Capture","Settings","Audio I/O").forEach { tab ->
            val label=when(tab){"Transfer"->"Transfer Function";"Impulse"->"Impulse Response";"Signal"->"Signal Generator";"Audio I/O"->"Audio I/O";else->tab}
            sidebar.addView(Button(this).apply { text=label; textSize=10f; isAllCaps=false; gravity=Gravity.START or Gravity.CENTER_VERTICAL; setPadding(9,4,4,4); minHeight=38; setTextColor(if(tab==selected) cyan else Color.rgb(220,233,243)); setBackgroundColor(if(tab==selected) Color.rgb(15,65,78) else Color.TRANSPARENT); setOnClickListener { stopCapture(); stopSignal(); selected=tab; buildShell(); renderPage() } },LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=3 })
        }
        root.addView(sidebar,LinearLayout.LayoutParams(150, -1))
        val main=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(10,0,0,0) }
        val top=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(4,0,4,3); minimumHeight=58 }
        top.addView(TextView(this).apply { text="C ACOUSTIC"; textSize=12f; typeface=android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD); setTextColor(cyan); maxLines=1 },LinearLayout.LayoutParams(0,-2,1f))
        top.addView(ImageView(this).apply {
            setImageResource(com.candstech.cacoustic.R.drawable.candstech_logo_original)
            scaleType=ImageView.ScaleType.FIT_CENTER
            adjustViewBounds=true
            contentDescription="Logo CANDSTECH"
            setPadding(2,0,2,0)
        }, LinearLayout.LayoutParams(220, 54))
        top.addView(TextView(this).apply { text="● DEVICE AUDIO"; textSize=9f; setTextColor(cyan); gravity=Gravity.END; maxLines=1 },LinearLayout.LayoutParams(0,-2,1f))
        main.addView(top, LinearLayout.LayoutParams(-1, 58))
        content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,2,0,0) }
        main.addView(ScrollView(this).apply { isFillViewport=true; addView(content) },LinearLayout.LayoutParams(-1,0,1f))
        root.addView(main,LinearLayout.LayoutParams(0,-1,1f)); setContentView(root)
    }
    private fun renderPage() {
        content.removeAllViews(); spectrumView=null; statusText=null; levelText=null; transferView=null; transferStatus=null
        when(selected) {
            "RTA" -> {
                heading("REAL-TIME ANALYZER","Live microphone FFT • 48 kHz preferred")
                metric("FFT SIZE","4096","Frequency resolution depends on sample rate")
                graphBox("RTA SPECTRUM", 320)
                levelText=TextView(this).apply { text="Level: —"; textSize=14f; setTextColor(cyan); setPadding(4,8,4,8) }; content.addView(levelText)
                statusText=TextView(this).apply { text="Mikrofon belum aktif"; textSize=11f; setTextColor(muted); setPadding(4,4,4,8) }; content.addView(statusText)
                compactActionRow(if (recording) "⏻ RTA ON" else "⏻ RTA OFF", "CAPTURE", {
                    if (recording) { stopCapture(); statusText?.text="RTA OFF • Capture dihentikan" }
                    else requestMicAndStart()
                    renderPage()
                }, { saveCurrentCapture() })
            }
            "Transfer" -> {
                heading("TRANSFER FUNCTION", "Dual-channel • H1 estimate • magnitude / phase / coherence")
                content.addView(TextView(this).apply {
                    text = "CH1 REFERENCE  •  CH2 MEASUREMENT  •  STEREO USB INTERFACE"
                    textSize = 10f; setTextColor(muted); setPadding(4, 0, 4, 5)
                })
                // Three stacked analyzer plots: selectable time-domain view, phase, and frequency with coherence overlay.
                val plots=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(6,6,6,6) }
                val timeHeader=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
                timeHeader.addView(TextView(this).apply { text="TIME RESPONSE  •  Lin / Log / ETC"; setTextColor(Color.WHITE); textSize=11f; setPadding(4,3,4,0) },LinearLayout.LayoutParams(0,-2,1f))
                val timeMode=Spinner(this)
                val timeModes=listOf("Lin","Log","ETC")
                timeMode.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,timeModes)
                timeMode.setSelection(0)
                timeHeader.addView(timeMode,LinearLayout.LayoutParams(100,-2))
                plots.addView(timeHeader)
                val timePlot=TimeResponseView(this)
                plots.addView(timePlot,LinearLayout.LayoutParams(-1,190).apply { topMargin=2; bottomMargin=3 })
                timeMode.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(parent:android.widget.AdapterView<*>?) {}
                    override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long) { timePlot.displayMode=timeModes[position]; timePlot.invalidate() }
                }
                val phasePlot=TransferView(this,"Phase")
                val frequencyPlot=TransferView(this,"Frequency+Coherence")
                transferView=frequencyPlot
                fun addTfPlot(title:String, plot:View, heightDp:Int) {
                    plots.addView(TextView(this).apply { text=title; setTextColor(Color.WHITE); textSize=11f; setPadding(4,3,4,0) })
                    plots.addView(plot,LinearLayout.LayoutParams(-1,heightDp).apply { topMargin=2; bottomMargin=5 })
                }
                addTfPlot("PHASE (°)",phasePlot,190)
                addTfPlot("MAGNITUDE (dB)  +  COHERENCE (red)",frequencyPlot,205)
                content.addView(plots,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 })
                transferStatus=TextView(this).apply { text="Belum ada capture dua kanal"; textSize=12f; setTextColor(cyan); setPadding(4,6,4,10) }; content.addView(transferStatus)
                val transferButtons = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, 2, 0, 2)
                }
                fun compactTfButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
                    text = label
                    textSize = 10f
                    minHeight = 34
                    minimumHeight = 34
                    minWidth = 0
                    isAllCaps = false
                    setPadding(6, 0, 6, 0)
                    setTextColor(cyan)
                    setOnClickListener { onClick() }
                }
                transferButtons.addView(compactTfButton(if (recording) "⏻ TRANSFER ON" else "⏻ TRANSFER OFF") {
                    if (recording) {
                        stopCapture()
                        transferStatus?.text = "Pengukuran dihentikan"
                        renderPage()
                    } else {
                        requestMicAndStartTransfer()
                    }
                }, LinearLayout.LayoutParams(0, 38, 1f).apply { rightMargin = 5 })
                transferButtons.addView(compactTfButton("CAPTURE") { saveCurrentCapture() },
                    LinearLayout.LayoutParams(0, 38, 0.72f))
                content.addView(transferButtons, LinearLayout.LayoutParams(-1, 42).apply { bottomMargin = 2 })
            }
            "Impulse" -> {
                heading("IMPULSE RESPONSE","Arrival time & delay analysis")
                graphBox("IMPULSE RESPONSE", 320)
                compactActionRow(if (recording) "⏻ IR ON" else "⏻ IR OFF", "CAPTURE", {
                    if (recording) stopCapture() else requestMicAndStart()
                    renderPage()
                }, { saveCurrentCapture() })
            }
            "SPL" -> {
                heading("SPL METER", "Relative level • manual reference calibration")
                metric("CALIBRATION OFFSET", String.format(java.util.Locale.US, "%.1f dB", splOffsetDb), "Offset awal hanya perkiraan; kalibrasikan dengan sound level calibrator atau meter referensi.")
                val input = EditText(this).apply {
                    setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                    hint = "Offset dB (mis. 120.0)"; setText(String.format(java.util.Locale.US, "%.1f", splOffsetDb)); setTextColor(Color.WHITE); setHintTextColor(muted); setBackgroundColor(panel)
                }
                content.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
                action("Save calibration offset") {
                    val value = input.text.toString().toFloatOrNull()
                    if (value == null || value !in 0f..200f) Toast.makeText(this, "Masukkan offset 0–200 dB", Toast.LENGTH_LONG).show()
                    else { splOffsetDb = value; getPreferences(Context.MODE_PRIVATE).edit().putFloat("spl_offset_db", value).apply(); Toast.makeText(this, "Offset tersimpan. Verifikasi dengan meter referensi.", Toast.LENGTH_LONG).show(); renderPage() }
                }
                levelText = TextView(this).apply { text = "SPL: menunggu capture"; textSize = 20f; setTextColor(cyan); setPadding(4, 12, 4, 8) }; content.addView(levelText)
                statusText = TextView(this).apply { text = "Belum ada capture"; textSize = 11f; setTextColor(muted); setPadding(4, 4, 4, 8) }; content.addView(statusText)
                action(if (recording) "⏻ SPL ON • TAP TO TURN OFF" else "⏻ SPL OFF • TAP TO TURN ON") { if (recording) { stopCapture(); statusText?.text = "SPL OFF • Capture dihentikan" } else requestMicAndStart(); renderPage() }
                info("SPL dihitung sebagai dBFS + offset manual. Ini belum menerapkan weighting A/C, response time, sensitivitas mikrofon, atau sertifikasi akurasi. Jangan anggap sebagai SPL terkalibrasi tanpa pembandingan alat referensi.")
            }
            "Signal" -> {
                heading("SIGNAL GENERATOR", "Pilih jenis sinyal, lalu ON/OFF")
                metric("AUDIO OUTPUT", "Pink Noise • Pink Sweep", "Sinyal dikirim ke output audio Android yang aktif, termasuk USB DAC jika didukung.")
                content.addView(TextView(this).apply {
                    text = "SIGNAL TYPE"
                    textSize = 11f
                    setTextColor(muted)
                    setPadding(4, 8, 4, 4)
                })
                val choices = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                choices.addView(Button(this).apply {
                    text = "Pink Noise"
                    isAllCaps = false
                    setTextColor(if (signalMode == "Pink Noise") cyan else Color.WHITE)
                    setBackgroundColor(if (signalMode == "Pink Noise") Color.rgb(20,55,69) else panel)
                    setOnClickListener {
                        if (signalRunning) stopSignal()
                        signalMode = "Pink Noise"
                        renderPage()
                    }
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = 6 })
                choices.addView(Button(this).apply {
                    text = "Pink Sweep"
                    isAllCaps = false
                    setTextColor(if (signalMode == "Pink Sweep") cyan else Color.WHITE)
                    setBackgroundColor(if (signalMode == "Pink Sweep") Color.rgb(20,55,69) else panel)
                    setOnClickListener {
                        if (signalRunning) stopSignal()
                        signalMode = "Pink Sweep"
                        renderPage()
                    }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                content.addView(choices)
                statusText=TextView(this).apply {
                    text = if (signalRunning) "$signalMode aktif" else "$signalMode siap • Generator OFF"
                    textSize = 14f
                    setTextColor(cyan)
                    setPadding(4, 12, 4, 10)
                }
                content.addView(statusText)
                action(if (signalRunning) "OFF • Stop Generator" else "ON • Start Generator") {
                    if (signalRunning) {
                        stopSignal()
                        statusText?.text = "$signalMode • Generator OFF"
                    } else {
                        startSignal(signalMode == "Pink Sweep")
                    }
                }
                info("Pilih Pink Noise atau Pink Sweep, lalu tekan ON. Tekan OFF untuk menghentikan output. Pink Sweep berjalan logaritmik 20 Hz–20 kHz dan berulang sekitar 10 detik. Mulai dengan volume rendah; output level belum dikalibrasi.")
            }
            "Capture" -> renderCaptureManager()
            "Settings" -> renderSettings()
            "Audio I/O" -> { heading("AUDIO DEVICE & ROUTING","Android input devices • USB/OTG where supported"); action("Refresh audio devices") { listAudioDevices() }; action("Open Android sound settings") { startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }; info(nativeDspStatus()); listAudioDevices() }
            else -> { selected="RTA"; renderPage() }
        }
        content.addView(TextView(this).apply { text="C ACOUSTIC • LANDSCAPE • LIVE RTA PROTOTYPE • DSP VALIDATION REQUIRED"; textSize=9f; setTextColor(muted); setPadding(0,18,0,8) })
    }
    private fun renderSettings() {
        heading("MEASUREMENT SETTINGS", "Parameter konfigurasi C ACOUSTIC")
        metric("FFT SIZE", settingsFftSize.toString(), "Resolusi frekuensi vs respons waktu")
        action("FFT SIZE • ubah 2048 / 4096 / 8192") { settingsFftSize = when(settingsFftSize){2048->4096;4096->8192;else->2048}; saveSettings(); renderPage() }
        metric("SAMPLE RATE", "$settingsSampleRate Hz", "Preferensi perangkat audio")
        action("SAMPLE RATE • ubah 44100 / 48000 / 96000") { settingsSampleRate = when(settingsSampleRate){44100->48000;48000->96000;else->44100}; saveSettings(); renderPage() }
        metric("AVERAGING", "$settingsAveraging frames", "Jumlah frame untuk stabilisasi tampilan")
        action("AVERAGING • ubah 1 / 4 / 8 / 16 / 32") { settingsAveraging = when(settingsAveraging){1->4;4->8;8->16;16->32;else->1}; saveSettings(); renderPage() }
        metric("WINDOW", settingsWindow, "Windowing mengurangi spectral leakage")
        action("WINDOW • Hann / Hamming / Rectangular") { settingsWindow = when(settingsWindow){"Hann"->"Hamming";"Hamming"->"Rectangular";else->"Hann"}; saveSettings(); renderPage() }
        metric("FREQUENCY SMOOTHING", settingsSmoothing, "Tingkat smoothing tampilan grafik")
        action("SMOOTHING • None / 1/6 octave / 1/3 octave / 1 octave") { settingsSmoothing = when(settingsSmoothing){"None"->"1/6 octave";"1/6 octave"->"1/3 octave";"1/3 octave"->"1 octave";else->"None"}; saveSettings(); renderPage() }
        metric("INPUT VOLUME (SOFTWARE GAIN)", String.format(java.util.Locale.US,"%.2f×  (%+.1f dB)",inputGain,20.0*log10(inputGain.toDouble())), "Gain digital sebelum analisis; tidak menaikkan sensitivitas hardware dan dapat menyebabkan clipping.")
        action("INPUT VOLUME −") { inputGain = (inputGain - 0.25f).coerceAtLeast(0.25f); saveSettings(); renderPage() }; action("INPUT VOLUME +") { inputGain = (inputGain + 0.25f).coerceAtMost(2.0f); saveSettings(); renderPage() }
        metric("OUTPUT VOLUME (SIGNAL GENERATOR)", String.format(java.util.Locale.US,"%.2f×  (%+.1f dB)",outputGain,20.0*log10(outputGain.toDouble())), "Gain digital generator; volume perangkat/DAC tetap dapat membatasi level aktual.")
        action("OUTPUT VOLUME −") { outputGain = (outputGain - 0.05f).coerceAtLeast(0.05f); saveSettings(); renderPage() }; action("OUTPUT VOLUME +") { outputGain = (outputGain + 0.05f).coerceAtMost(1.0f); saveSettings(); renderPage() }
        metric("SPL CALIBRATION OFFSET", String.format(java.util.Locale.US,"%.1f dB",splOffsetDb), "Pengaturan offset saat ini")
        action("Configure SPL calibration") { selected="SPL"; buildShell(); renderPage() }
        action("Audio input & output devices") { selected="Audio I/O"; buildShell(); renderPage() }
        info("PENTING: pengaturan disimpan sebagai preferensi. Pada build ini, jalur DSP masih memakai 4096 sampel dan 48 kHz tetap; FFT size, sample rate, averaging, window, dan smoothing belum seluruhnya diterapkan ke mesin DSP. Jangan anggap perubahan preferensi mengubah pemrosesan aktual sebelum integrasi DSP selesai.")
    }
    private fun saveSettings() {
        getPreferences(Context.MODE_PRIVATE).edit().putInt("fft_size",settingsFftSize).putInt("sample_rate",settingsSampleRate).putInt("averaging",settingsAveraging).putString("window",settingsWindow).putString("smoothing",settingsSmoothing).putFloat("input_gain",inputGain).putFloat("output_gain",outputGain).apply()
    }

    private fun savedCaptures(): MutableList<SavedCapture> {
        val out = mutableListOf<SavedCapture>()
        val raw = getPreferences(Context.MODE_PRIVATE).getString("saved_capture_list", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i); val a = o.getJSONArray("spectrum")
                val data = FloatArray(a.length()) { j -> a.optDouble(j, 0.0).toFloat() }
                out.add(SavedCapture(o.optLong("id"), o.optString("name", "Capture ${i+1}"), o.optString("created", ""), data))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun saveCurrentCapture() {
        val spectrum = when (selected) {
            "Transfer" -> tfMagnitude.copyOf()
            else -> latestSpectrum.copyOf()
        }
        if (spectrum.size < 4 || spectrum.drop(1).all { it <= 1e-9f }) {
            Toast.makeText(this, "Belum ada data terukur yang bisa disimpan. Jalankan pengukuran terlebih dahulu.", Toast.LENGTH_LONG).show(); return
        }
        val captures = savedCaptures()
        val name = "Capture ${captures.size + 1}"
        captures.add(SavedCapture(System.currentTimeMillis(), name, java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()), spectrum))
        persistCaptures(captures.takeLast(10))
        Toast.makeText(this, "$name tersimpan sebagai snapshot ${selected}*. Buka Capture Manager untuk memilihnya.", Toast.LENGTH_LONG).show()
    }

    private fun persistCaptures(captures: List<SavedCapture>) {
        val arr = JSONArray()
        captures.forEach { c ->
            val o = JSONObject().put("id", c.id).put("name", c.name).put("created", c.created)
            val a = JSONArray(); c.spectrum.forEach { a.put(it.toDouble()) }; o.put("spectrum", a); arr.put(o)
        }
        getPreferences(Context.MODE_PRIVATE).edit().putString("saved_capture_list", arr.toString()).apply()
    }

    private fun renderCaptureManager() {
        heading("CAPTURE MANAGER", "Simpan, pilih, dan bandingkan hasil spektrum")
        val nameInput = EditText(this).apply { hint = "Nama capture (mis. Main Speaker)"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted); setBackgroundColor(panel); setPadding(12, 8, 12, 8) }
        captureNameInput = nameInput
        content.addView(nameInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
        action("SAVE CURRENT SPECTRUM") {
            val spectrum = latestSpectrum.copyOf()
            if (spectrum.size < 4 || spectrum.drop(1).all { it <= 1e-9f }) {
                Toast.makeText(this, "Belum ada data spektrum. Buka RTA, mulai capture, lalu kembali ke sini.", Toast.LENGTH_LONG).show()
            } else {
                val captures = savedCaptures()
                val custom = nameInput.text.toString().trim()
                val name = if (custom.isBlank()) "Capture ${captures.size + 1}" else custom
                captures.add(SavedCapture(System.currentTimeMillis(), name, java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()), spectrum))
                persistCaptures(captures.takeLast(10)); chosenCaptureIds.clear(); chosenCaptureIds.add(captures.last().id)
                Toast.makeText(this, "Capture tersimpan", Toast.LENGTH_SHORT).show(); renderPage()
            }
        }
        val captures = savedCaptures()
        metric("CAPTURE LIBRARY", "${captures.size} tersimpan", "Pilih satu atau beberapa hasil. Data spektrum tersimpan lokal di perangkat; maksimum 10 capture.")
        if (captures.isEmpty()) info("Belum ada hasil tersimpan. Buka tab RTA, tekan Start live RTA, tunggu grafik bergerak, lalu tekan Save current spectrum to Capture Manager.")
        captures.asReversed().forEach { cap ->
            val cb = CheckBox(this).apply {
                text = "${cap.name}\n${cap.created}"
                textSize = 13f; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(cyan)
                isChecked = chosenCaptureIds.contains(cap.id)
                setPadding(8, 8, 8, 8)
                setOnCheckedChangeListener { _, checked -> if (checked) chosenCaptureIds.add(cap.id) else chosenCaptureIds.remove(cap.id); updateSelectedCapturePreview() }
            }
            content.addView(cb, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 4 })
        }
        heading("SELECTED CAPTURE PREVIEW", "Magnitude spectrum • display range ±60 dB")
        val preview = SpectrumView(this); spectrumView = preview; content.addView(preview, LinearLayout.LayoutParams(-1, 210).apply { bottomMargin = 8 })
        action("REFRESH SELECTED GRAPH") { updateSelectedCapturePreview(); preview.invalidate() }
        action("CLEAR SELECTION") { chosenCaptureIds.clear(); renderPage() }
        action("DELETE SELECTED CAPTURES") {
            val ids = chosenCaptureIds.toSet(); persistCaptures(savedCaptures().filterNot { ids.contains(it.id) }); chosenCaptureIds.clear(); renderPage()
        }
        heading("TARGET CURVE & GAIN ADVISOR", "Target 80 phon • 20 Hz–20 kHz")
        metric("TARGET", "ISO 226 • 80 phon", "Target ISO harus tervalidasi; di atas 12,5 kHz tandai sebagai target belum tersedia. Capture RTA satu kanal tidak cukup untuk Auto Phase.")
        listOf("Equal-loudness • 80 phon", "House Curve", "Flat Response").forEach { label ->
            action(label) { Toast.makeText(this, "Target dipilih: $label. Perhitungan EQ belum aktif sampai data target ISO dan mesin rekomendasi tervalidasi.", Toast.LENGTH_LONG).show() }
        }
        graphBox("MEASURED / TARGET / PREDICTED")
        info("Tahap ini menyimpan dan memilih spektrum RTA. Prediksi EQ dan rekomendasi gain yang valid memerlukan target numerik tervalidasi, kalibrasi SPL, serta model filter; spektrum mono tidak dapat dipakai untuk menyimpulkan fase atau delay.")
        heading("AUTO PHASE / ALIGNMENT", "Aksi berada di dalam Capture Manager")
        action("RUN AUTO PHASE ON SELECTED CAPTURES") {
            val chosen = savedCaptures().filter { chosenCaptureIds.contains(it.id) }
            val msg = if (chosen.size < 2) "Pilih minimal dua capture. Auto Phase memerlukan data dua kanal yang sinkron; snapshot RTA saja belum cukup." else "${chosen.size} capture dipilih. Analisis delay/fase belum aktif: data saat ini hanya snapshot magnitude RTA, bukan phase/IR tersinkron."
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
        info("Auto Phase sudah ditempatkan di menu Capture. Tombol ini belum menghitung delay/polaritas karena versi ini belum menyimpan phase/impulse response dua kanal yang sinkron.")
        updateSelectedCapturePreview()
    }

    private fun updateSelectedCapturePreview() {
        val selectedCaps = savedCaptures().filter { chosenCaptureIds.contains(it.id) }
        if (selectedCaps.isNotEmpty()) {
            val n = selectedCaps.minOf { it.spectrum.size }
            latestSpectrum = FloatArray(n) { i -> selectedCaps.map { it.spectrum[i] }.average().toFloat() }
        }
        spectrumView?.invalidate()
    }

    private fun startSignal(sweep: Boolean) {
        stopSignal()
        stopCapture()
        val sr = 48000
        val minBytes = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBytes <= 0) { Toast.makeText(this, "Output audio tidak didukung", Toast.LENGTH_LONG).show(); return }
        try {
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(minBytes, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            if (track.state != AudioTrack.STATE_INITIALIZED) { track.release(); Toast.makeText(this, "AudioTrack gagal diinisialisasi", Toast.LENGTH_LONG).show(); return }
            signalTrack = track; signalRunning = true; track.play()
            statusText?.text = if (sweep) "Pink sweep aktif • 20 Hz–20 kHz • 10 s/putaran" else "Pink noise aktif"
            signalThread = thread(name="CAcousticSignal", isDaemon=true) {
                val block = ShortArray(2048)
                val rng = java.util.Random()
                var phase = 0.0
                var index = 0L
                var b0=0.0; var b1=0.0; var b2=0.0; var b3=0.0; var b4=0.0; var b5=0.0; var b6=0.0
                while (signalRunning) {
                    for (i in block.indices) {
                        val sample: Double
                        if (sweep) {
                            val t = (index % (sr * 10L)).toDouble() / sr
                            val duration = 10.0
                            val f0 = 20.0; val f1 = 20000.0
                            val k = duration / kotlin.math.ln(f1 / f0)
                            phase = 2.0 * Math.PI * f0 * k * (kotlin.math.exp(t / k) - 1.0)
                            sample = kotlin.math.sin(phase) * 0.18
                        } else {
                            val white = rng.nextDouble() * 2.0 - 1.0
                            b0 = 0.99886*b0 + white*0.0555179
                            b1 = 0.99332*b1 + white*0.0750759
                            b2 = 0.96900*b2 + white*0.1538520
                            b3 = 0.86650*b3 + white*0.3104856
                            b4 = 0.55000*b4 + white*0.5329522
                            b5 = -0.7616*b5 - white*0.0168980
                            val pink = b0+b1+b2+b3+b4+b5+b6+white*0.5362
                            b6 = white*0.115926
                            sample = (pink * 0.035).coerceIn(-0.25, 0.25)
                        }
                        block[i] = (sample.coerceIn(-0.25, 0.25) * outputGain.toDouble() * 32767.0).toInt().coerceIn(-32768,32767).toShort()
                        index++
                    }
                    var off = 0
                    while (off < block.size && signalRunning) {
                        val wrote = track.write(block, off, block.size-off, AudioTrack.WRITE_BLOCKING)
                        if (wrote <= 0) break else off += wrote
                    }
                }
            }
        } catch (e: Exception) {
            stopSignal()
            Toast.makeText(this, "Gagal memulai generator: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopSignal() {
        signalRunning = false
        try { signalTrack?.pause() } catch (_: Exception) {}
        try { signalTrack?.flush() } catch (_: Exception) {}
        try { signalTrack?.stop() } catch (_: Exception) {}
        try { signalTrack?.release() } catch (_: Exception) {}
        signalTrack = null
        signalThread = null
    }

    private fun requestMicAndStart() { if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),MIC_REQUEST); return }; startCapture() }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) { super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==MIC_REQUEST && grantResults.isNotEmpty() && grantResults[0]==PackageManager.PERMISSION_GRANTED) { if(selected=="Transfer") startTransferCapture() else startCapture() } else Toast.makeText(this,"Izin mikrofon diperlukan untuk RTA live",Toast.LENGTH_LONG).show() }

    private fun startCapture() {
        if(recording) return
        val sampleRate=48000; val minBytes=AudioRecord.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        if(minBytes<=0) { Toast.makeText(this,"Format audio 48 kHz tidak didukung; coba perangkat lain",Toast.LENGTH_LONG).show(); return }
        val bufferBytes=max(minBytes,4096*2*2)
        try {
            val rec=AudioRecord(MediaRecorder.AudioSource.UNPROCESSED,sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,bufferBytes).let { if(it.state!=AudioRecord.STATE_INITIALIZED) { it.release(); AudioRecord(MediaRecorder.AudioSource.MIC,sampleRate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,bufferBytes) } else it }
            if(rec.state!=AudioRecord.STATE_INITIALIZED) { rec.release(); Toast.makeText(this,"AudioRecord gagal diinisialisasi",Toast.LENGTH_LONG).show(); return }
            audioRecord=rec; recording=true; rec.startRecording(); statusText?.text="Capture aktif • 48 kHz • mikrofon Android"; Toast.makeText(this,"RTA live aktif",Toast.LENGTH_SHORT).show()
            audioThread=thread(name="CAcousticAudio", isDaemon=true) {
                val n=4096; val shorts=ShortArray(n); val floats=FloatArray(n)
                while(recording) {
                    var offset=0
                    while(offset<n && recording) { val got=rec.read(shorts,offset,n-offset,AudioRecord.READ_BLOCKING); if(got>0) offset+=got else break }
                    if(!recording || offset<n) continue
                    var peak=0f
                    for(i in 0 until n) { floats[i]=(shorts[i]/32768f*inputGain).coerceIn(-1f,1f); peak=max(peak,kotlin.math.abs(floats[i])) }
                    latestRms=nativeRms(floats); latestPeak=peak
                    val mags=nativeFftMagnitude(floats); if(mags.isNotEmpty()) latestSpectrum=mags
                    runOnUiThread {
                        spectrumView?.invalidate()
                        if (selected == "SPL") levelText?.text = "Level estimasi ${formatDb(latestRms)} dBFS\nSPL relatif ${String.format(java.util.Locale.US, "%.1f", 20.0 * log10(max(1e-9f, latestRms).toDouble()) + splOffsetDb)} dB SPL"
                        else levelText?.text = "RMS ${formatDb(latestRms)} dBFS   •   Peak ${formatDb(latestPeak)} dBFS"
                        statusText?.text = "Capture aktif • ${sampleRate} Hz • input Android"
                    }
                }
            }
        } catch(e:Exception) { recording=false; Toast.makeText(this,"Gagal memulai audio: ${e.message}",Toast.LENGTH_LONG).show() }
    }
    private fun requestMicAndStartTransfer() {
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),MIC_REQUEST); return }
        startTransferCapture()
    }
    private fun startTransferCapture() {
        if(recording) return
        val sr=48000; val mask=AudioFormat.CHANNEL_IN_STEREO
        val minBytes=AudioRecord.getMinBufferSize(sr,mask,AudioFormat.ENCODING_PCM_16BIT)
        if(minBytes<=0) { transferStatus?.text="Stereo 48 kHz tidak didukung input ini. Coba interface USB 2-in."; return }
        val bytes=max(minBytes,4096*2*2)
        try {
            val rec=AudioRecord(MediaRecorder.AudioSource.UNPROCESSED,sr,mask,AudioFormat.ENCODING_PCM_16BIT,bytes)
            if(rec.state!=AudioRecord.STATE_INITIALIZED) { rec.release(); transferStatus?.text="AudioRecord stereo gagal. Perangkat mungkin hanya menyediakan input mono."; return }
            audioRecord=rec; recording=true; rec.startRecording(); transferStatus?.text="Capture stereo aktif • Ch1 reference / Ch2 measurement"
            audioThread=thread(name="CAcousticTransfer",isDaemon=true) {
                val n=4096; val interleaved=ShortArray(n*2); val r=FloatArray(n); val m=FloatArray(n)
                val avgR=FloatArray(n/2+1); val avgM=FloatArray(n/2+1); val avgCr=FloatArray(n/2+1); val avgCi=FloatArray(n/2+1); var frames=0
                while(recording) {
                    var off=0; while(off<interleaved.size && recording) { val got=rec.read(interleaved,off,interleaved.size-off,AudioRecord.READ_BLOCKING); if(got>0) off+=got else break }
                    if(!recording || off<interleaved.size) continue
                    for(i in 0 until n){r[i]=interleaved[i*2]/32768f;m[i]=interleaved[i*2+1]/32768f}
                    val raw=nativeTransferFrame(r,m); if(raw.size<(n/2+1)*4) continue
                    frames++
                    for(k in avgR.indices){ val j=k*4; avgR[k]=avgR[k]*0.85f+raw[j]*0.15f; avgM[k]=avgM[k]*0.85f+raw[j+1]*0.15f; avgCr[k]=avgCr[k]*0.85f+raw[j+2]*0.15f; avgCi[k]=avgCi[k]*0.85f+raw[j+3]*0.15f }
                    for(k in avgR.indices){ tfMagnitude[k]=(10.0*log10(max(1e-12f,avgM[k])/max(1e-12f,avgR[k]))).toFloat(); tfPhase[k]=Math.toDegrees(kotlin.math.atan2(avgCi[k].toDouble(),avgCr[k].toDouble())).toFloat(); tfCoherence[k]=((avgCr[k]*avgCr[k]+avgCi[k]*avgCi[k])/max(1e-20f,avgR[k]*avgM[k])).coerceIn(0f,1f) }
                    runOnUiThread { transferView?.invalidate(); transferStatus?.text="TF live • 48 kHz • avg frames $frames • coherence = estimate" }
                }
            }
        } catch(e:Exception) { recording=false; transferStatus?.text="Gagal memulai stereo capture: ${e.message}" }
    }

    private fun stopCapture() { recording=false; try { audioRecord?.stop() } catch(_:Exception){}; try { audioRecord?.release() } catch(_:Exception){}; audioRecord=null; audioThread=null }
    private fun formatDb(v:Float):String = if(v<=0f) "−∞" else String.format(java.util.Locale.US,"%.1f",20.0*log10(v.toDouble()))

    private fun heading(t:String,d:String) { content.addView(TextView(this).apply { text=t; textSize=17f; setTextColor(Color.WHITE); typeface=android.graphics.Typeface.DEFAULT_BOLD }); content.addView(TextView(this).apply { text=d; textSize=11f; setTextColor(muted); setPadding(0,3,0,12) }) }
    private fun metric(l:String,v:String,d:String) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(12,12,12,12) }; box.addView(TextView(this).apply { text=l; textSize=10f; setTextColor(muted) }); box.addView(TextView(this).apply { text=v; textSize=20f; setTextColor(cyan); typeface=android.graphics.Typeface.DEFAULT_BOLD; setPadding(0,4,0,2) }); box.addView(TextView(this).apply { text=d; textSize=11f; setTextColor(Color.WHITE) }); content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=10 }) }
    private fun graphBox(title:String, heightDp:Int=320) { val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(8,8,8,8) }; box.addView(TextView(this).apply { text=title; textSize=12f; setTextColor(Color.WHITE); typeface=android.graphics.Typeface.DEFAULT_BOLD }); val graph=SpectrumView(this); spectrumView=graph; box.addView(graph,LinearLayout.LayoutParams(-1,heightDp).apply { topMargin=5 }); content.addView(box,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=6 }) }
    private fun compactActionRow(toggleLabel:String, captureLabel:String, toggle:()->Unit, capture:()->Unit) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(0,2,0,4) }
        fun smallButton(label:String, handler:()->Unit)=Button(this).apply { text=label; textSize=11f; isAllCaps=false; minHeight=36; minimumHeight=36; minWidth=0; setPadding(6,0,6,0); setTextColor(cyan); setOnClickListener { handler() } }
        row.addView(smallButton(toggleLabel,toggle),LinearLayout.LayoutParams(0,38,1f).apply { rightMargin=6 })
        row.addView(smallButton(captureLabel,capture),LinearLayout.LayoutParams(0,38,1f))
        content.addView(row,LinearLayout.LayoutParams(-1,42))
    }
    private fun info(s:String) { content.addView(TextView(this).apply { text=s; textSize=12f; setTextColor(muted); setPadding(6,8,6,12) }) }
    private fun action(label:String,fn:()->Unit) { content.addView(Button(this).apply { text=label; isAllCaps=false; setTextColor(cyan); setOnClickListener { fn() } },LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 }) }
    private fun listAudioDevices() { val am=getSystemService(Context.AUDIO_SERVICE) as AudioManager; val devices=if(Build.VERSION.SDK_INT>=23) am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList() else emptyList(); val lines=devices.map { d -> "${d.productName} • ${typeName(d.type)} • ${d.channelCounts.joinToString()} ch" }; info(if(lines.isEmpty()) "Tidak ada input device eksternal yang terdeteksi. Mikrofon bawaan mungkin tetap tersedia melalui AudioRecord." else "Input terdeteksi:\n"+lines.joinToString("\n")) }
    private fun typeName(t:Int)=when(t){AudioDeviceInfo.TYPE_BUILTIN_MIC->"Built-in mic";AudioDeviceInfo.TYPE_USB_DEVICE->"USB device";AudioDeviceInfo.TYPE_USB_HEADSET->"USB headset";AudioDeviceInfo.TYPE_WIRED_HEADSET->"Wired headset";AudioDeviceInfo.TYPE_BLUETOOTH_SCO->"Bluetooth SCO";else->"Audio type $t"}

    private inner class TimeResponseView(ctx:Context):View(ctx) {
        var displayMode:String = "Lin"
        private var plotZoom = 1f
        private val zoomDetector = android.view.ScaleGestureDetector(ctx, object: android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: android.view.ScaleGestureDetector): Boolean {
                plotZoom = (plotZoom * detector.scaleFactor).coerceIn(1f, 5f)
                invalidate()
                return true
            }
        })
        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            zoomDetector.onTouchEvent(event)
            tapDetector.onTouchEvent(event)
            return true
        }
        private val tapDetector = android.view.GestureDetector(ctx, object: android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                plotZoom = 1f
                invalidate()
                return true
            }
        })
        private val grid=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(35,57,73); strokeWidth=1f }
        private val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cyan; strokeWidth=2.2f; style=Paint.Style.STROKE }
        private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=muted; textSize=10f }
        override fun onDraw(c:Canvas) {
            super.onDraw(c); c.drawColor(Color.rgb(7,19,31))
            c.save()
            c.scale(plotZoom, plotZoom, width / 2f, height / 2f)
            val l=38f; val r=width-8f; val t=8f; val b=height-19f
            for(i in 0..4) { val y=t+(b-t)*i/4f; c.drawLine(l,y,r,y,grid) }
            for(i in 0..4) { val x=l+(r-l)*i/4f; c.drawLine(x,t,x,b,grid) }
            val labels=when(displayMode) { "Log" -> listOf("-10 ms","-1 ms","0","1 ms","10 ms"); "ETC" -> listOf("0","-10 dB","-20 dB","-30 dB","-40 dB"); else -> listOf("-20 ms","-10 ms","0","10 ms","20 ms") }
            labels.forEachIndexed { i,label -> c.drawText(label,(l+(r-l)*i/4f)-15,b+13,text) }
            if(displayMode=="ETC") c.drawText("ETC / TIME DATA NOT CAPTURED",l+6f,(t+b)/2f,text)
            else c.drawText("Impulse/time data requires synchronized IR capture",l+6f,(t+b)/2f,text)
            c.drawLine(l,(t+b)/2f,r,(t+b)/2f,grid)
            c.restore()
        }
    }

    private inner class TransferView(ctx:Context, private val plotMode:String = tfDisplayMode):View(ctx) {
        private var plotZoom = 1f
        private val zoomDetector = android.view.ScaleGestureDetector(ctx, object: android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: android.view.ScaleGestureDetector): Boolean {
                plotZoom = (plotZoom * detector.scaleFactor).coerceIn(1f, 5f)
                invalidate()
                return true
            }
        })
        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            zoomDetector.onTouchEvent(event)
            tapDetector.onTouchEvent(event)
            return true
        }
        private val tapDetector = android.view.GestureDetector(ctx, object: android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                plotZoom = 1f
                invalidate()
                return true
            }
        })
        private val grid=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(35,57,73); strokeWidth=1f }
        private val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cyan; strokeWidth=2.2f; style=Paint.Style.STROKE }
        private val coherenceLine=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(255,70,80); strokeWidth=2.2f; style=Paint.Style.STROKE }
        private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=muted; textSize=10f }
        override fun onDraw(c:Canvas) {
            super.onDraw(c); c.drawColor(Color.rgb(7,19,31))
            c.save()
            c.scale(plotZoom, plotZoom, width / 2f, height / 2f)
            val l=36f; val r=width-8f; val t=8f; val b=height-19f
            val mode=plotMode
            val minY=if(mode=="Phase") -180f else -18f
            val maxY=if(mode=="Phase") 180f else 18f
            for(i in 0..4){
                val v=maxY-(maxY-minY)*i/4f; val y=t+(b-t)*i/4f
                c.drawLine(l,y,r,y,grid)
                c.drawText(String.format(java.util.Locale.US,"%.0f",v),2f,y-2,text)
            }
            val freqLabels=listOf("20","100","1k","10k","20k")
            for(i in 0..4){val x=l+(r-l)*i/4f;c.drawLine(x,t,x,b,grid);c.drawText(freqLabels[i],x-8,b+13,text)}
            if(mode=="Frequency+Coherence") {
                drawSeries(c,tfMagnitude,minY,maxY,l,r,t,b,line)
                // Coherence is overlaid in red using an independent 0..1 scale mapped to the plot height.
                val path=Path(); val a=tfCoherence; val count=min(500,a.size-1)
                for(i in 1..count){val v=a[i].coerceIn(0f,1f);val y=b-v*(b-t);val x=l+(i.toFloat()/count)*(r-l);if(i==1)path.moveTo(x,y)else path.lineTo(x,y)}
                c.drawPath(path,coherenceLine)
                c.drawText("1.0",r-25,t+9,text); c.drawText("0.0",r-25,b-2,text)
            } else {
                val a=if(mode=="Phase") tfPhase else tfMagnitude
                drawSeries(c,a,minY,maxY,l,r,t,b,line)
            }
            c.restore()
        }
        private fun drawSeries(c:Canvas,a:FloatArray,minY:Float,maxY:Float,l:Float,r:Float,t:Float,b:Float,paint:Paint) {
            if(a.size<4)return
            val path=Path(); val count=min(500,a.size-1)
            for(i in 1..count){val v=a[i].coerceIn(minY,maxY);val y=t+((maxY-v)/(maxY-minY))*(b-t);val x=l+(i.toFloat()/count)*(r-l);if(i==1)path.moveTo(x,y)else path.lineTo(x,y)}
            c.drawPath(path,paint)
        }
    }

    private inner class SpectrumView(ctx:Context):View(ctx) {
        private var plotZoom = 1f
        private val zoomDetector = android.view.ScaleGestureDetector(ctx, object: android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: android.view.ScaleGestureDetector): Boolean { plotZoom=(plotZoom*detector.scaleFactor).coerceIn(1f,5f); invalidate(); return true }
        })
        private val tapDetector = android.view.GestureDetector(ctx, object: android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                plotZoom = 1f
                invalidate()
                return true
            }
        })
        private val grid=Paint( Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(35,57,73); strokeWidth=1f }
        private val line=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=cyan; strokeWidth=3f; style=Paint.Style.STROKE }
        private val text=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=muted; textSize=10f }
        override fun onTouchEvent(event:android.view.MotionEvent):Boolean { zoomDetector.onTouchEvent(event); tapDetector.onTouchEvent(event); return true }
        override fun onDraw(c:Canvas) { super.onDraw(c); c.drawColor(Color.rgb(7,19,31)); c.save(); c.scale(plotZoom,plotZoom,width/2f,height/2f); val left=34f; val right=width-8f; val top=12f; val bottom=height-22f
            // Fixed display range: +60 dB at the top, -60 dB at the bottom.
            for(i in 0..6) { val db=60-i*20; val y=top+(bottom-top)*i/6f; c.drawLine(left,y,right,y,grid); c.drawText("${db} dB",2f,y-2,text) }
            val freqs=listOf("20","100","1k","10k","20k"); for(i in 0..4) { val x=left+(right-left)*i/4f; c.drawLine(x,top,x,bottom,grid); c.drawText(freqs[i],x-8,bottom+15,text) }
            val mags=latestSpectrum; if(mags.size<4) return
            val path=Path(); val count= min(500,mags.size-1); for(i in 1..count) { val norm=i.toFloat()/count; val db=(20*log10(max(1e-6f,mags[i]))).coerceIn(-60f,60f); val y=top+((60f-db)/120f)*(bottom-top); val x=left+norm*(right-left); if(i==1) path.moveTo(x,y) else path.lineTo(x,y) }; c.drawPath(path,line); c.restore()
        }
    }
}
